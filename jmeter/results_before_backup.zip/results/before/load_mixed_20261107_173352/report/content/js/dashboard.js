/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/seeker/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/jobs/search?title=java"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/employer/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/jobseeker/favorites/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/update-status/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs/get/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/submit-application"], "isController": false}, {"data": [1.0, 500, 1500, "GET /employer/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (seeker)"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/jobseeker/favorites/{userId}/{jobId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (employer)"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/resume/resume-pdf/{id}"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 59096, 0, 0.0, 5.169283877081391, 0, 272, 2.0, 10.0, 29.0, 43.0, 236.5770468702461, 2734.9999279099247, 45.4967503482842], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /jobs", 3830, 0, 0.0, 5.866057441253271, 3, 24, 5.0, 8.0, 9.0, 13.0, 15.398161065568827, 238.26161910356973, 2.646558933144642], "isController": false}, {"data": ["GET /applications/seeker/{seekerId}", 3190, 0, 0.0, 5.969592476489031, 1, 27, 6.0, 9.0, 10.0, 14.0, 12.850363757945875, 18.230560583271565, 2.4596399380443277], "isController": false}, {"data": ["GET /jobseeker/jobs/search?title=java", 12818, 0, 0.0, 1.8782961460446286, 1, 38, 2.0, 3.0, 3.0, 5.0, 51.47935885747792, 1499.0200174741358, 10.25565352238818], "isController": false}, {"data": ["GET /applications/employer/{userId}", 5309, 0, 0.0, 30.074590318327456, 9, 104, 29.0, 42.0, 46.0, 55.0, 21.360746761084734, 210.60492102000686, 4.130300643256619], "isController": false}, {"data": ["GET /api/jobseeker/favorites/{seekerId}", 397, 0, 0.0, 5.851385390428214, 1, 19, 6.0, 9.0, 10.0, 16.039999999999964, 1.621718776807379, 2.6835502837497245, 0.3167419485951912], "isController": false}, {"data": ["POST /applications/update-status/{id}", 569, 0, 0.0, 4.441124780316349, 2, 16, 4.0, 6.0, 7.0, 10.0, 2.3216056208152955, 0.45466583057583165, 0.6982954406358507], "isController": false}, {"data": ["GET /jobs/get/{id}", 12804, 0, 0.0, 1.157450796626053, 0, 24, 1.0, 2.0, 2.0, 3.0, 51.46964239773604, 17.282570852913157, 9.298714690997235], "isController": false}, {"data": ["GET /jobseeker/dashboard/{userId}", 12827, 0, 0.0, 1.8119591486707642, 0, 185, 2.0, 3.0, 3.0, 5.0, 51.43494143546272, 539.1985623644154, 9.844969259131537], "isController": false}, {"data": ["POST /applications/submit-application", 349, 0, 0.0, 7.028653295128937, 4, 34, 6.0, 10.0, 11.0, 16.5, 1.4055974191781484, 0.26846983075439096, 0.48866472776115316], "isController": false}, {"data": ["GET /employer/dashboard/{userId}", 5314, 0, 0.0, 3.8562288295069522, 2, 29, 4.0, 5.0, 6.0, 9.0, 21.36238467568491, 207.81794115947417, 4.0680322380454665], "isController": false}, {"data": ["POST /auth/login (seeker)", 40, 0, 0.0, 80.59999999999998, 73, 132, 78.0, 87.0, 124.14999999999984, 132.0, 4.17144644905621, 1.315798049848785, 1.1102809860256544], "isController": false}, {"data": ["POST /api/jobseeker/favorites/{userId}/{jobId}", 398, 0, 0.0, 4.298994974874377, 2, 16, 4.0, 6.0, 7.0, 10.0, 1.619604539775941, 0.4012768628504226, 0.4570954218703584], "isController": false}, {"data": ["POST /auth/login (employer)", 10, 0, 0.0, 77.89999999999998, 75, 84, 77.5, 83.5, 84.0, 84.0, 1.1029006286533583, 0.34681054924451304, 0.2897268253005404], "isController": false}, {"data": ["GET /api/resume/resume-pdf/{id}", 1241, 0, 0.0, 6.9790491539081385, 3, 272, 6.0, 10.0, 11.0, 15.579999999999927, 5.032277947187439, 9.743001640001541, 0.9730381186944462], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 59096, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
