/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 74.0, "minX": 0.0, "maxY": 2855.0, "series": [{"data": [[0.0, 74.0], [0.1, 77.0], [0.2, 77.0], [0.3, 78.0], [0.4, 78.0], [0.5, 79.0], [0.6, 79.0], [0.7, 80.0], [0.8, 80.0], [0.9, 80.0], [1.0, 81.0], [1.1, 81.0], [1.2, 81.0], [1.3, 82.0], [1.4, 82.0], [1.5, 82.0], [1.6, 83.0], [1.7, 83.0], [1.8, 84.0], [1.9, 84.0], [2.0, 85.0], [2.1, 85.0], [2.2, 86.0], [2.3, 86.0], [2.4, 87.0], [2.5, 87.0], [2.6, 88.0], [2.7, 88.0], [2.8, 89.0], [2.9, 89.0], [3.0, 90.0], [3.1, 91.0], [3.2, 91.0], [3.3, 92.0], [3.4, 92.0], [3.5, 93.0], [3.6, 93.0], [3.7, 94.0], [3.8, 95.0], [3.9, 95.0], [4.0, 96.0], [4.1, 97.0], [4.2, 97.0], [4.3, 98.0], [4.4, 98.0], [4.5, 99.0], [4.6, 99.0], [4.7, 100.0], [4.8, 100.0], [4.9, 101.0], [5.0, 101.0], [5.1, 102.0], [5.2, 102.0], [5.3, 103.0], [5.4, 103.0], [5.5, 104.0], [5.6, 104.0], [5.7, 104.0], [5.8, 105.0], [5.9, 105.0], [6.0, 106.0], [6.1, 106.0], [6.2, 107.0], [6.3, 107.0], [6.4, 107.0], [6.5, 107.0], [6.6, 108.0], [6.7, 108.0], [6.8, 108.0], [6.9, 109.0], [7.0, 109.0], [7.1, 109.0], [7.2, 109.0], [7.3, 110.0], [7.4, 110.0], [7.5, 111.0], [7.6, 111.0], [7.7, 111.0], [7.8, 111.0], [7.9, 112.0], [8.0, 112.0], [8.1, 112.0], [8.2, 113.0], [8.3, 113.0], [8.4, 113.0], [8.5, 113.0], [8.6, 114.0], [8.7, 114.0], [8.8, 114.0], [8.9, 114.0], [9.0, 115.0], [9.1, 115.0], [9.2, 115.0], [9.3, 115.0], [9.4, 116.0], [9.5, 116.0], [9.6, 116.0], [9.7, 117.0], [9.8, 117.0], [9.9, 117.0], [10.0, 117.0], [10.1, 117.0], [10.2, 118.0], [10.3, 118.0], [10.4, 118.0], [10.5, 118.0], [10.6, 119.0], [10.7, 119.0], [10.8, 119.0], [10.9, 119.0], [11.0, 120.0], [11.1, 120.0], [11.2, 120.0], [11.3, 120.0], [11.4, 120.0], [11.5, 121.0], [11.6, 121.0], [11.7, 121.0], [11.8, 121.0], [11.9, 122.0], [12.0, 122.0], [12.1, 122.0], [12.2, 122.0], [12.3, 123.0], [12.4, 123.0], [12.5, 123.0], [12.6, 123.0], [12.7, 123.0], [12.8, 124.0], [12.9, 124.0], [13.0, 124.0], [13.1, 124.0], [13.2, 125.0], [13.3, 125.0], [13.4, 125.0], [13.5, 125.0], [13.6, 126.0], [13.7, 126.0], [13.8, 126.0], [13.9, 126.0], [14.0, 127.0], [14.1, 127.0], [14.2, 127.0], [14.3, 127.0], [14.4, 128.0], [14.5, 128.0], [14.6, 128.0], [14.7, 129.0], [14.8, 129.0], [14.9, 129.0], [15.0, 129.0], [15.1, 130.0], [15.2, 130.0], [15.3, 130.0], [15.4, 130.0], [15.5, 131.0], [15.6, 131.0], [15.7, 131.0], [15.8, 132.0], [15.9, 132.0], [16.0, 132.0], [16.1, 132.0], [16.2, 133.0], [16.3, 133.0], [16.4, 133.0], [16.5, 134.0], [16.6, 134.0], [16.7, 134.0], [16.8, 135.0], [16.9, 135.0], [17.0, 135.0], [17.1, 136.0], [17.2, 136.0], [17.3, 136.0], [17.4, 137.0], [17.5, 137.0], [17.6, 138.0], [17.7, 138.0], [17.8, 139.0], [17.9, 139.0], [18.0, 139.0], [18.1, 140.0], [18.2, 141.0], [18.3, 141.0], [18.4, 142.0], [18.5, 142.0], [18.6, 143.0], [18.7, 144.0], [18.8, 144.0], [18.9, 145.0], [19.0, 146.0], [19.1, 147.0], [19.2, 148.0], [19.3, 149.0], [19.4, 150.0], [19.5, 151.0], [19.6, 152.0], [19.7, 153.0], [19.8, 154.0], [19.9, 155.0], [20.0, 156.0], [20.1, 158.0], [20.2, 159.0], [20.3, 161.0], [20.4, 162.0], [20.5, 165.0], [20.6, 167.0], [20.7, 168.0], [20.8, 170.0], [20.9, 172.0], [21.0, 173.0], [21.1, 175.0], [21.2, 177.0], [21.3, 178.0], [21.4, 180.0], [21.5, 181.0], [21.6, 182.0], [21.7, 183.0], [21.8, 184.0], [21.9, 185.0], [22.0, 186.0], [22.1, 187.0], [22.2, 188.0], [22.3, 188.0], [22.4, 189.0], [22.5, 190.0], [22.6, 191.0], [22.7, 191.0], [22.8, 192.0], [22.9, 193.0], [23.0, 193.0], [23.1, 194.0], [23.2, 195.0], [23.3, 196.0], [23.4, 197.0], [23.5, 197.0], [23.6, 198.0], [23.7, 198.0], [23.8, 199.0], [23.9, 200.0], [24.0, 200.0], [24.1, 201.0], [24.2, 201.0], [24.3, 202.0], [24.4, 202.0], [24.5, 203.0], [24.6, 203.0], [24.7, 204.0], [24.8, 204.0], [24.9, 205.0], [25.0, 205.0], [25.1, 206.0], [25.2, 206.0], [25.3, 207.0], [25.4, 207.0], [25.5, 208.0], [25.6, 208.0], [25.7, 209.0], [25.8, 209.0], [25.9, 209.0], [26.0, 210.0], [26.1, 210.0], [26.2, 211.0], [26.3, 211.0], [26.4, 211.0], [26.5, 212.0], [26.6, 212.0], [26.7, 213.0], [26.8, 213.0], [26.9, 214.0], [27.0, 214.0], [27.1, 214.0], [27.2, 215.0], [27.3, 215.0], [27.4, 215.0], [27.5, 216.0], [27.6, 216.0], [27.7, 217.0], [27.8, 217.0], [27.9, 217.0], [28.0, 218.0], [28.1, 218.0], [28.2, 219.0], [28.3, 219.0], [28.4, 219.0], [28.5, 220.0], [28.6, 220.0], [28.7, 221.0], [28.8, 221.0], [28.9, 221.0], [29.0, 222.0], [29.1, 222.0], [29.2, 222.0], [29.3, 223.0], [29.4, 223.0], [29.5, 224.0], [29.6, 224.0], [29.7, 224.0], [29.8, 225.0], [29.9, 225.0], [30.0, 226.0], [30.1, 226.0], [30.2, 226.0], [30.3, 227.0], [30.4, 227.0], [30.5, 227.0], [30.6, 228.0], [30.7, 228.0], [30.8, 228.0], [30.9, 229.0], [31.0, 229.0], [31.1, 229.0], [31.2, 229.0], [31.3, 230.0], [31.4, 230.0], [31.5, 231.0], [31.6, 231.0], [31.7, 231.0], [31.8, 232.0], [31.9, 232.0], [32.0, 232.0], [32.1, 233.0], [32.2, 233.0], [32.3, 233.0], [32.4, 234.0], [32.5, 234.0], [32.6, 234.0], [32.7, 235.0], [32.8, 235.0], [32.9, 236.0], [33.0, 236.0], [33.1, 236.0], [33.2, 237.0], [33.3, 237.0], [33.4, 237.0], [33.5, 238.0], [33.6, 238.0], [33.7, 239.0], [33.8, 239.0], [33.9, 239.0], [34.0, 240.0], [34.1, 240.0], [34.2, 240.0], [34.3, 241.0], [34.4, 241.0], [34.5, 241.0], [34.6, 242.0], [34.7, 242.0], [34.8, 242.0], [34.9, 243.0], [35.0, 243.0], [35.1, 243.0], [35.2, 244.0], [35.3, 244.0], [35.4, 245.0], [35.5, 245.0], [35.6, 246.0], [35.7, 246.0], [35.8, 246.0], [35.9, 247.0], [36.0, 247.0], [36.1, 248.0], [36.2, 248.0], [36.3, 249.0], [36.4, 249.0], [36.5, 249.0], [36.6, 250.0], [36.7, 250.0], [36.8, 251.0], [36.9, 251.0], [37.0, 251.0], [37.1, 252.0], [37.2, 252.0], [37.3, 253.0], [37.4, 253.0], [37.5, 254.0], [37.6, 254.0], [37.7, 255.0], [37.8, 255.0], [37.9, 256.0], [38.0, 256.0], [38.1, 257.0], [38.2, 257.0], [38.3, 258.0], [38.4, 258.0], [38.5, 259.0], [38.6, 259.0], [38.7, 260.0], [38.8, 260.0], [38.9, 261.0], [39.0, 261.0], [39.1, 262.0], [39.2, 262.0], [39.3, 263.0], [39.4, 264.0], [39.5, 264.0], [39.6, 265.0], [39.7, 265.0], [39.8, 266.0], [39.9, 267.0], [40.0, 267.0], [40.1, 268.0], [40.2, 269.0], [40.3, 269.0], [40.4, 270.0], [40.5, 270.0], [40.6, 271.0], [40.7, 272.0], [40.8, 273.0], [40.9, 273.0], [41.0, 274.0], [41.1, 275.0], [41.2, 275.0], [41.3, 276.0], [41.4, 277.0], [41.5, 278.0], [41.6, 278.0], [41.7, 279.0], [41.8, 280.0], [41.9, 281.0], [42.0, 281.0], [42.1, 282.0], [42.2, 283.0], [42.3, 284.0], [42.4, 285.0], [42.5, 286.0], [42.6, 287.0], [42.7, 288.0], [42.8, 288.0], [42.9, 289.0], [43.0, 290.0], [43.1, 290.0], [43.2, 291.0], [43.3, 292.0], [43.4, 293.0], [43.5, 293.0], [43.6, 294.0], [43.7, 295.0], [43.8, 295.0], [43.9, 296.0], [44.0, 297.0], [44.1, 298.0], [44.2, 298.0], [44.3, 299.0], [44.4, 299.0], [44.5, 300.0], [44.6, 301.0], [44.7, 302.0], [44.8, 302.0], [44.9, 303.0], [45.0, 303.0], [45.1, 304.0], [45.2, 305.0], [45.3, 305.0], [45.4, 306.0], [45.5, 306.0], [45.6, 307.0], [45.7, 308.0], [45.8, 308.0], [45.9, 309.0], [46.0, 309.0], [46.1, 310.0], [46.2, 310.0], [46.3, 311.0], [46.4, 311.0], [46.5, 312.0], [46.6, 313.0], [46.7, 313.0], [46.8, 314.0], [46.9, 314.0], [47.0, 315.0], [47.1, 315.0], [47.2, 316.0], [47.3, 316.0], [47.4, 317.0], [47.5, 317.0], [47.6, 318.0], [47.7, 319.0], [47.8, 319.0], [47.9, 319.0], [48.0, 320.0], [48.1, 320.0], [48.2, 321.0], [48.3, 321.0], [48.4, 322.0], [48.5, 322.0], [48.6, 323.0], [48.7, 323.0], [48.8, 324.0], [48.9, 325.0], [49.0, 325.0], [49.1, 326.0], [49.2, 327.0], [49.3, 327.0], [49.4, 328.0], [49.5, 328.0], [49.6, 328.0], [49.7, 329.0], [49.8, 329.0], [49.9, 330.0], [50.0, 330.0], [50.1, 331.0], [50.2, 331.0], [50.3, 332.0], [50.4, 332.0], [50.5, 332.0], [50.6, 333.0], [50.7, 333.0], [50.8, 334.0], [50.9, 334.0], [51.0, 335.0], [51.1, 335.0], [51.2, 336.0], [51.3, 336.0], [51.4, 337.0], [51.5, 337.0], [51.6, 338.0], [51.7, 338.0], [51.8, 339.0], [51.9, 339.0], [52.0, 340.0], [52.1, 340.0], [52.2, 341.0], [52.3, 341.0], [52.4, 342.0], [52.5, 342.0], [52.6, 342.0], [52.7, 343.0], [52.8, 343.0], [52.9, 344.0], [53.0, 344.0], [53.1, 345.0], [53.2, 345.0], [53.3, 346.0], [53.4, 346.0], [53.5, 347.0], [53.6, 347.0], [53.7, 348.0], [53.8, 348.0], [53.9, 349.0], [54.0, 349.0], [54.1, 349.0], [54.2, 350.0], [54.3, 350.0], [54.4, 351.0], [54.5, 351.0], [54.6, 352.0], [54.7, 353.0], [54.8, 353.0], [54.9, 354.0], [55.0, 354.0], [55.1, 355.0], [55.2, 355.0], [55.3, 356.0], [55.4, 356.0], [55.5, 357.0], [55.6, 357.0], [55.7, 358.0], [55.8, 358.0], [55.9, 359.0], [56.0, 359.0], [56.1, 360.0], [56.2, 361.0], [56.3, 361.0], [56.4, 362.0], [56.5, 362.0], [56.6, 363.0], [56.7, 363.0], [56.8, 364.0], [56.9, 364.0], [57.0, 365.0], [57.1, 366.0], [57.2, 366.0], [57.3, 367.0], [57.4, 367.0], [57.5, 368.0], [57.6, 369.0], [57.7, 369.0], [57.8, 370.0], [57.9, 370.0], [58.0, 371.0], [58.1, 371.0], [58.2, 372.0], [58.3, 373.0], [58.4, 373.0], [58.5, 374.0], [58.6, 375.0], [58.7, 376.0], [58.8, 376.0], [58.9, 378.0], [59.0, 378.0], [59.1, 379.0], [59.2, 380.0], [59.3, 381.0], [59.4, 382.0], [59.5, 383.0], [59.6, 384.0], [59.7, 385.0], [59.8, 385.0], [59.9, 387.0], [60.0, 388.0], [60.1, 389.0], [60.2, 390.0], [60.3, 391.0], [60.4, 393.0], [60.5, 394.0], [60.6, 396.0], [60.7, 397.0], [60.8, 399.0], [60.9, 401.0], [61.0, 402.0], [61.1, 404.0], [61.2, 406.0], [61.3, 408.0], [61.4, 410.0], [61.5, 413.0], [61.6, 415.0], [61.7, 418.0], [61.8, 421.0], [61.9, 424.0], [62.0, 427.0], [62.1, 431.0], [62.2, 435.0], [62.3, 439.0], [62.4, 444.0], [62.5, 450.0], [62.6, 455.0], [62.7, 461.0], [62.8, 465.0], [62.9, 469.0], [63.0, 472.0], [63.1, 477.0], [63.2, 480.0], [63.3, 483.0], [63.4, 487.0], [63.5, 491.0], [63.6, 494.0], [63.7, 497.0], [63.8, 500.0], [63.9, 502.0], [64.0, 505.0], [64.1, 507.0], [64.2, 508.0], [64.3, 510.0], [64.4, 511.0], [64.5, 513.0], [64.6, 515.0], [64.7, 516.0], [64.8, 517.0], [64.9, 519.0], [65.0, 520.0], [65.1, 522.0], [65.2, 523.0], [65.3, 525.0], [65.4, 526.0], [65.5, 528.0], [65.6, 529.0], [65.7, 530.0], [65.8, 531.0], [65.9, 533.0], [66.0, 534.0], [66.1, 535.0], [66.2, 536.0], [66.3, 537.0], [66.4, 538.0], [66.5, 539.0], [66.6, 540.0], [66.7, 542.0], [66.8, 542.0], [66.9, 543.0], [67.0, 544.0], [67.1, 545.0], [67.2, 546.0], [67.3, 547.0], [67.4, 548.0], [67.5, 549.0], [67.6, 550.0], [67.7, 551.0], [67.8, 552.0], [67.9, 552.0], [68.0, 553.0], [68.1, 554.0], [68.2, 555.0], [68.3, 556.0], [68.4, 556.0], [68.5, 557.0], [68.6, 558.0], [68.7, 558.0], [68.8, 559.0], [68.9, 559.0], [69.0, 560.0], [69.1, 560.0], [69.2, 561.0], [69.3, 562.0], [69.4, 562.0], [69.5, 563.0], [69.6, 563.0], [69.7, 564.0], [69.8, 564.0], [69.9, 565.0], [70.0, 565.0], [70.1, 566.0], [70.2, 566.0], [70.3, 567.0], [70.4, 567.0], [70.5, 568.0], [70.6, 568.0], [70.7, 569.0], [70.8, 569.0], [70.9, 570.0], [71.0, 570.0], [71.1, 571.0], [71.2, 571.0], [71.3, 572.0], [71.4, 572.0], [71.5, 573.0], [71.6, 573.0], [71.7, 574.0], [71.8, 574.0], [71.9, 575.0], [72.0, 575.0], [72.1, 576.0], [72.2, 576.0], [72.3, 577.0], [72.4, 577.0], [72.5, 578.0], [72.6, 579.0], [72.7, 579.0], [72.8, 580.0], [72.9, 580.0], [73.0, 581.0], [73.1, 581.0], [73.2, 582.0], [73.3, 582.0], [73.4, 583.0], [73.5, 583.0], [73.6, 584.0], [73.7, 584.0], [73.8, 585.0], [73.9, 586.0], [74.0, 586.0], [74.1, 587.0], [74.2, 587.0], [74.3, 588.0], [74.4, 589.0], [74.5, 589.0], [74.6, 590.0], [74.7, 590.0], [74.8, 591.0], [74.9, 592.0], [75.0, 592.0], [75.1, 593.0], [75.2, 594.0], [75.3, 594.0], [75.4, 595.0], [75.5, 596.0], [75.6, 597.0], [75.7, 597.0], [75.8, 598.0], [75.9, 599.0], [76.0, 600.0], [76.1, 601.0], [76.2, 602.0], [76.3, 603.0], [76.4, 603.0], [76.5, 604.0], [76.6, 605.0], [76.7, 606.0], [76.8, 607.0], [76.9, 608.0], [77.0, 609.0], [77.1, 610.0], [77.2, 611.0], [77.3, 612.0], [77.4, 613.0], [77.5, 614.0], [77.6, 615.0], [77.7, 616.0], [77.8, 618.0], [77.9, 619.0], [78.0, 620.0], [78.1, 622.0], [78.2, 623.0], [78.3, 625.0], [78.4, 626.0], [78.5, 627.0], [78.6, 628.0], [78.7, 630.0], [78.8, 631.0], [78.9, 633.0], [79.0, 635.0], [79.1, 636.0], [79.2, 638.0], [79.3, 641.0], [79.4, 642.0], [79.5, 645.0], [79.6, 648.0], [79.7, 651.0], [79.8, 655.0], [79.9, 658.0], [80.0, 661.0], [80.1, 666.0], [80.2, 669.0], [80.3, 673.0], [80.4, 676.0], [80.5, 680.0], [80.6, 684.0], [80.7, 687.0], [80.8, 692.0], [80.9, 697.0], [81.0, 700.0], [81.1, 705.0], [81.2, 710.0], [81.3, 715.0], [81.4, 719.0], [81.5, 723.0], [81.6, 727.0], [81.7, 730.0], [81.8, 733.0], [81.9, 736.0], [82.0, 738.0], [82.1, 741.0], [82.2, 743.0], [82.3, 746.0], [82.4, 748.0], [82.5, 749.0], [82.6, 751.0], [82.7, 753.0], [82.8, 755.0], [82.9, 756.0], [83.0, 758.0], [83.1, 759.0], [83.2, 761.0], [83.3, 762.0], [83.4, 763.0], [83.5, 764.0], [83.6, 765.0], [83.7, 766.0], [83.8, 767.0], [83.9, 768.0], [84.0, 769.0], [84.1, 770.0], [84.2, 770.0], [84.3, 771.0], [84.4, 772.0], [84.5, 772.0], [84.6, 773.0], [84.7, 774.0], [84.8, 774.0], [84.9, 775.0], [85.0, 776.0], [85.1, 777.0], [85.2, 777.0], [85.3, 778.0], [85.4, 778.0], [85.5, 779.0], [85.6, 780.0], [85.7, 780.0], [85.8, 781.0], [85.9, 782.0], [86.0, 782.0], [86.1, 783.0], [86.2, 784.0], [86.3, 784.0], [86.4, 785.0], [86.5, 785.0], [86.6, 786.0], [86.7, 786.0], [86.8, 787.0], [86.9, 787.0], [87.0, 788.0], [87.1, 789.0], [87.2, 789.0], [87.3, 790.0], [87.4, 791.0], [87.5, 791.0], [87.6, 792.0], [87.7, 792.0], [87.8, 793.0], [87.9, 794.0], [88.0, 794.0], [88.1, 795.0], [88.2, 795.0], [88.3, 796.0], [88.4, 797.0], [88.5, 797.0], [88.6, 798.0], [88.7, 798.0], [88.8, 799.0], [88.9, 800.0], [89.0, 800.0], [89.1, 801.0], [89.2, 802.0], [89.3, 802.0], [89.4, 803.0], [89.5, 804.0], [89.6, 804.0], [89.7, 805.0], [89.8, 805.0], [89.9, 806.0], [90.0, 807.0], [90.1, 807.0], [90.2, 808.0], [90.3, 809.0], [90.4, 810.0], [90.5, 810.0], [90.6, 811.0], [90.7, 812.0], [90.8, 812.0], [90.9, 813.0], [91.0, 814.0], [91.1, 815.0], [91.2, 815.0], [91.3, 816.0], [91.4, 817.0], [91.5, 818.0], [91.6, 818.0], [91.7, 819.0], [91.8, 820.0], [91.9, 821.0], [92.0, 822.0], [92.1, 822.0], [92.2, 823.0], [92.3, 824.0], [92.4, 825.0], [92.5, 826.0], [92.6, 826.0], [92.7, 827.0], [92.8, 828.0], [92.9, 828.0], [93.0, 829.0], [93.1, 830.0], [93.2, 831.0], [93.3, 832.0], [93.4, 833.0], [93.5, 833.0], [93.6, 834.0], [93.7, 835.0], [93.8, 836.0], [93.9, 837.0], [94.0, 838.0], [94.1, 839.0], [94.2, 840.0], [94.3, 841.0], [94.4, 842.0], [94.5, 843.0], [94.6, 844.0], [94.7, 845.0], [94.8, 846.0], [94.9, 847.0], [95.0, 848.0], [95.1, 849.0], [95.2, 851.0], [95.3, 852.0], [95.4, 853.0], [95.5, 854.0], [95.6, 856.0], [95.7, 857.0], [95.8, 859.0], [95.9, 861.0], [96.0, 862.0], [96.1, 864.0], [96.2, 865.0], [96.3, 868.0], [96.4, 869.0], [96.5, 872.0], [96.6, 874.0], [96.7, 876.0], [96.8, 879.0], [96.9, 883.0], [97.0, 887.0], [97.1, 892.0], [97.2, 898.0], [97.3, 909.0], [97.4, 928.0], [97.5, 955.0], [97.6, 972.0], [97.7, 982.0], [97.8, 995.0], [97.9, 1003.0], [98.0, 1009.0], [98.1, 1015.0], [98.2, 1022.0], [98.3, 1030.0], [98.4, 1037.0], [98.5, 1047.0], [98.6, 1055.0], [98.7, 1067.0], [98.8, 1086.0], [98.9, 1169.0], [99.0, 1330.0], [99.1, 1429.0], [99.2, 1449.0], [99.3, 1460.0], [99.4, 1471.0], [99.5, 1485.0], [99.6, 1499.0], [99.7, 1512.0], [99.8, 1527.0], [99.9, 1567.0]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 7723.0, "series": [{"data": [[0.0, 1741.0], [2100.0, 14.0], [2200.0, 5.0], [600.0, 1889.0], [700.0, 2976.0], [2800.0, 1.0], [200.0, 7723.0], [800.0, 3139.0], [900.0, 240.0], [1000.0, 370.0], [1100.0, 34.0], [300.0, 6192.0], [1200.0, 17.0], [1300.0, 29.0], [1400.0, 208.0], [1500.0, 125.0], [100.0, 7251.0], [400.0, 1110.0], [1600.0, 4.0], [1900.0, 1.0], [500.0, 4577.0]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2800.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 147.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 24031.0, "series": [{"data": [[0.0, 24031.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 13468.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 147.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 7.943175783324483, "minX": 1.79399694E12, "maxY": 20.0, "series": [{"data": [[1.7939973E12, 10.0], [1.79399712E12, 10.0], [1.79399718E12, 10.0], [1.793997E12, 10.0], [1.79399706E12, 10.0], [1.79399736E12, 10.0], [1.79399694E12, 7.943175783324483], [1.79399742E12, 8.333333333333334], [1.79399724E12, 10.0]], "isOverall": false, "label": "Gradino 1", "isController": false}, {"data": [[1.7939973E12, 10.0], [1.79399712E12, 8.070205479452053], [1.79399718E12, 10.0], [1.79399736E12, 10.0], [1.79399742E12, 8.269230769230772], [1.79399724E12, 10.0]], "isOverall": false, "label": "Gradino 3", "isController": false}, {"data": [[1.7939973E12, 10.0], [1.79399712E12, 10.0], [1.79399718E12, 10.0], [1.79399706E12, 9.140144665461104], [1.79399736E12, 10.0], [1.79399742E12, 8.333333333333334], [1.79399724E12, 10.0]], "isOverall": false, "label": "Gradino 2", "isController": false}, {"data": [[1.7939973E12, 16.22680412371135], [1.79399736E12, 20.0], [1.79399742E12, 16.56363636363636]], "isOverall": false, "label": "Gradino 5", "isController": false}, {"data": [[1.7939973E12, 20.0], [1.79399736E12, 20.0], [1.79399742E12, 15.799999999999997], [1.79399724E12, 18.36347724620773]], "isOverall": false, "label": "Gradino 4", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399742E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 79.16666666666669, "minX": 1.0, "maxY": 819.4788709144941, "series": [{"data": [[2.0, 104.79245283018867], [3.0, 97.64935064935065], [4.0, 85.77227722772275], [5.0, 88.33333333333333], [6.0, 91.0279720279721], [7.0, 93.79999999999997], [8.0, 101.39024390243905], [9.0, 112.14970059880241], [10.0, 118.56519583539901], [11.0, 132.33526011560696], [12.0, 140.66860465116278], [13.0, 153.6136363636364], [14.0, 168.9881656804734], [15.0, 175.65714285714284], [16.0, 202.251572327044], [17.0, 201.26285714285711], [18.0, 211.67647058823542], [19.0, 221.45454545454547], [20.0, 235.02287955548334], [21.0, 250.50292397660814], [22.0, 258.6629213483147], [23.0, 266.7134502923976], [24.0, 277.0225988700564], [25.0, 286.20571428571424], [26.0, 305.5146198830408], [27.0, 320.5588235294118], [28.0, 333.284023668639], [29.0, 345.7261904761905], [30.0, 356.3418620006608], [31.0, 390.9876543209875], [32.0, 398.45000000000016], [33.0, 395.2068965517241], [34.0, 407.8690476190476], [35.0, 421.09638554216855], [36.0, 421.28235294117644], [37.0, 439.0833333333333], [38.0, 439.02247191011236], [39.0, 454.72093023255803], [40.0, 474.906976744186], [41.0, 469.9418604651163], [42.0, 476.2674418604651], [43.0, 515.758620689655], [44.0, 505.0674157303371], [45.0, 534.3409090909092], [46.0, 526.5232558139536], [47.0, 542.2068965517244], [48.0, 562.306818181818], [49.0, 561.0114942528735], [50.0, 590.5915985997681], [51.0, 592.0352941176469], [52.0, 619.3295454545455], [53.0, 598.3370786516855], [54.0, 651.6296296296294], [55.0, 646.6235294117647], [56.0, 676.0588235294117], [57.0, 649.9058823529414], [58.0, 647.6590909090909], [59.0, 718.0470588235294], [60.0, 680.5348837209303], [61.0, 750.607142857143], [62.0, 714.392857142857], [63.0, 716.5116279069769], [64.0, 744.8764044943821], [65.0, 773.4512195121948], [66.0, 779.2068965517241], [67.0, 766.1034482758619], [68.0, 801.3146067415732], [69.0, 790.0000000000002], [70.0, 819.4788709144941], [1.0, 79.16666666666669]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}, {"data": [[35.06351272379555, 413.3735589438415]], "isOverall": false, "label": "POST /auth/login (seeker)-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 70.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 612.0, "minX": 1.79399694E12, "maxY": 27798.516666666666, "series": [{"data": [[1.7939973E12, 17329.233333333334], [1.79399712E12, 17218.6], [1.79399718E12, 17206.55], [1.793997E12, 17159.433333333334], [1.79399706E12, 17402.2], [1.79399736E12, 17411.4], [1.79399694E12, 6415.266666666666], [1.79399742E12, 612.0], [1.79399724E12, 17246.183333333334]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7939973E12, 27612.583333333332], [1.79399712E12, 27485.65], [1.79399718E12, 27510.783333333333], [1.793997E12, 27434.75], [1.79399706E12, 27778.866666666665], [1.79399736E12, 27798.516666666666], [1.79399694E12, 10212.683333333332], [1.79399742E12, 977.1], [1.79399724E12, 27482.25]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399742E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 103.81518852894314, "minX": 1.79399694E12, "maxY": 843.5333333333334, "series": [{"data": [[1.7939973E12, 661.3381139489197], [1.79399712E12, 274.9210266535037], [1.79399718E12, 354.746448303079], [1.793997E12, 118.28333992876938], [1.79399706E12, 213.6294198085562], [1.79399736E12, 819.8017965241149], [1.79399694E12, 103.81518852894314], [1.79399742E12, 843.5333333333334], [1.79399724E12, 546.4709830240838]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399742E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 103.81465746149765, "minX": 1.79399694E12, "maxY": 843.5333333333334, "series": [{"data": [[1.7939973E12, 661.3377210216116], [1.79399712E12, 274.92082922013833], [1.79399718E12, 354.74625098658237], [1.793997E12, 118.28274633953342], [1.79399706E12, 213.62922445790173], [1.79399736E12, 819.8017965241149], [1.79399694E12, 103.81465746149765], [1.79399742E12, 843.5333333333334], [1.79399724E12, 546.4707856296861]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399742E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.019192718638701943, "minX": 1.79399694E12, "maxY": 0.038888888888888876, "series": [{"data": [[1.7939973E12, 0.02691552062868371], [1.79399712E12, 0.02250740375123394], [1.79399718E12, 0.02052091554853994], [1.793997E12, 0.019192718638701943], [1.79399706E12, 0.02129322133229141], [1.79399736E12, 0.02987697715289986], [1.79399694E12, 0.02442910249601696], [1.79399742E12, 0.038888888888888876], [1.79399724E12, 0.022897749703908364]], "isOverall": false, "label": "POST /auth/login (seeker)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399742E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 74.0, "minX": 1.79399694E12, "maxY": 2855.0, "series": [{"data": [[1.7939973E12, 2110.0], [1.79399712E12, 863.0], [1.79399718E12, 873.0], [1.793997E12, 247.0], [1.79399706E12, 556.0], [1.79399736E12, 2855.0], [1.79399694E12, 215.0], [1.79399742E12, 1577.0], [1.79399724E12, 1560.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7939973E12, 105.0], [1.79399712E12, 88.0], [1.79399718E12, 86.0], [1.793997E12, 77.0], [1.79399706E12, 79.0], [1.79399736E12, 192.0], [1.79399694E12, 74.0], [1.79399742E12, 228.0], [1.79399724E12, 107.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7939973E12, 844.0], [1.79399712E12, 360.0], [1.79399718E12, 403.0], [1.793997E12, 140.0], [1.79399706E12, 262.0], [1.79399736E12, 875.0], [1.79399694E12, 132.0], [1.79399742E12, 887.6], [1.79399724E12, 645.3000000000002]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7939973E12, 1438.0], [1.79399712E12, 553.3400000000001], [1.79399718E12, 611.2400000000016], [1.793997E12, 163.0], [1.79399706E12, 326.0], [1.79399736E12, 1534.0], [1.79399694E12, 152.16000000000008], [1.79399742E12, 1557.56], [1.79399724E12, 1056.33]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7939973E12, 616.0], [1.79399712E12, 258.0], [1.79399718E12, 344.0], [1.793997E12, 119.0], [1.79399706E12, 218.0], [1.79399736E12, 805.0], [1.79399694E12, 102.0], [1.79399742E12, 827.5], [1.79399724E12, 558.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.7939973E12, 1025.0], [1.79399712E12, 387.0], [1.79399718E12, 531.0], [1.793997E12, 147.0], [1.79399706E12, 279.0], [1.79399736E12, 1438.0], [1.79399694E12, 138.0], [1.79399742E12, 1478.4499999999998], [1.79399724E12, 977.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399742E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 76.5, "minX": 7.0, "maxY": 795.0, "series": [{"data": [[33.0, 77.0], [39.0, 79.0], [47.0, 79.0], [49.0, 78.0], [59.0, 81.0], [60.0, 147.5], [63.0, 85.0], [71.0, 85.0], [69.0, 242.0], [68.0, 300.0], [75.0, 158.5], [77.0, 230.0], [79.0, 366.0], [78.0, 424.5], [76.0, 187.5], [81.0, 275.0], [82.0, 393.0], [80.0, 317.5], [83.0, 377.0], [84.0, 295.5], [86.0, 272.0], [85.0, 373.0], [87.0, 307.0], [90.0, 326.0], [88.0, 331.0], [89.0, 373.0], [91.0, 775.0], [92.0, 795.0], [7.0, 77.0], [13.0, 443.0], [21.0, 78.0], [26.0, 76.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 92.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 76.5, "minX": 7.0, "maxY": 795.0, "series": [{"data": [[33.0, 77.0], [39.0, 79.0], [47.0, 79.0], [49.0, 78.0], [59.0, 81.0], [60.0, 147.5], [63.0, 85.0], [71.0, 85.0], [69.0, 242.0], [68.0, 300.0], [75.0, 158.5], [77.0, 230.0], [79.0, 366.0], [78.0, 424.5], [76.0, 187.5], [81.0, 275.0], [82.0, 393.0], [80.0, 317.5], [83.0, 377.0], [84.0, 295.5], [86.0, 272.0], [85.0, 373.0], [87.0, 307.0], [90.0, 326.0], [88.0, 331.0], [89.0, 373.0], [91.0, 775.0], [92.0, 795.0], [7.0, 77.0], [13.0, 443.0], [21.0, 78.0], [26.0, 76.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 92.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.8333333333333333, "minX": 1.79399694E12, "maxY": 85.46666666666667, "series": [{"data": [[1.7939973E12, 85.16666666666667], [1.79399712E12, 84.6], [1.79399718E12, 84.46666666666667], [1.793997E12, 84.23333333333333], [1.79399706E12, 85.46666666666667], [1.79399736E12, 85.35], [1.79399694E12, 31.55], [1.79399742E12, 1.8333333333333333], [1.79399724E12, 84.76666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399742E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79399694E12, "maxY": 85.35, "series": [{"data": [[1.7939973E12, 84.83333333333333], [1.79399712E12, 84.41666666666667], [1.79399718E12, 84.46666666666667], [1.793997E12, 84.23333333333333], [1.79399706E12, 85.31666666666666], [1.79399736E12, 85.35], [1.79399694E12, 31.383333333333333], [1.79399742E12, 3.0], [1.79399724E12, 84.43333333333334]], "isOverall": false, "label": "302", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399742E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79399694E12, "maxY": 85.35, "series": [{"data": [[1.7939973E12, 84.83333333333333], [1.79399712E12, 84.41666666666667], [1.79399718E12, 84.46666666666667], [1.793997E12, 84.23333333333333], [1.79399706E12, 85.31666666666666], [1.79399736E12, 85.35], [1.79399694E12, 31.383333333333333], [1.79399742E12, 3.0], [1.79399724E12, 84.43333333333334]], "isOverall": false, "label": "POST /auth/login (seeker)-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399742E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79399694E12, "maxY": 85.35, "series": [{"data": [[1.7939973E12, 84.83333333333333], [1.79399712E12, 84.41666666666667], [1.79399718E12, 84.46666666666667], [1.793997E12, 84.23333333333333], [1.79399706E12, 85.31666666666666], [1.79399736E12, 85.35], [1.79399694E12, 31.383333333333333], [1.79399742E12, 3.0], [1.79399724E12, 84.43333333333334]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399742E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

