/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "maxY": 1363.0, "series": [{"data": [[0.0, 5.0], [0.1, 6.0], [0.2, 6.0], [0.3, 6.0], [0.4, 6.0], [0.5, 6.0], [0.6, 6.0], [0.7, 6.0], [0.8, 6.0], [0.9, 6.0], [1.0, 6.0], [1.1, 6.0], [1.2, 6.0], [1.3, 6.0], [1.4, 6.0], [1.5, 7.0], [1.6, 7.0], [1.7, 7.0], [1.8, 7.0], [1.9, 7.0], [2.0, 7.0], [2.1, 7.0], [2.2, 7.0], [2.3, 7.0], [2.4, 7.0], [2.5, 7.0], [2.6, 7.0], [2.7, 7.0], [2.8, 7.0], [2.9, 7.0], [3.0, 7.0], [3.1, 7.0], [3.2, 7.0], [3.3, 7.0], [3.4, 7.0], [3.5, 7.0], [3.6, 7.0], [3.7, 7.0], [3.8, 7.0], [3.9, 7.0], [4.0, 7.0], [4.1, 7.0], [4.2, 7.0], [4.3, 7.0], [4.4, 7.0], [4.5, 7.0], [4.6, 7.0], [4.7, 7.0], [4.8, 7.0], [4.9, 7.0], [5.0, 7.0], [5.1, 7.0], [5.2, 7.0], [5.3, 7.0], [5.4, 7.0], [5.5, 7.0], [5.6, 7.0], [5.7, 7.0], [5.8, 7.0], [5.9, 7.0], [6.0, 7.0], [6.1, 7.0], [6.2, 7.0], [6.3, 7.0], [6.4, 7.0], [6.5, 7.0], [6.6, 7.0], [6.7, 7.0], [6.8, 7.0], [6.9, 7.0], [7.0, 7.0], [7.1, 7.0], [7.2, 7.0], [7.3, 7.0], [7.4, 7.0], [7.5, 7.0], [7.6, 7.0], [7.7, 7.0], [7.8, 7.0], [7.9, 7.0], [8.0, 7.0], [8.1, 7.0], [8.2, 7.0], [8.3, 7.0], [8.4, 7.0], [8.5, 7.0], [8.6, 7.0], [8.7, 7.0], [8.8, 7.0], [8.9, 7.0], [9.0, 7.0], [9.1, 7.0], [9.2, 7.0], [9.3, 7.0], [9.4, 7.0], [9.5, 7.0], [9.6, 7.0], [9.7, 7.0], [9.8, 7.0], [9.9, 8.0], [10.0, 8.0], [10.1, 8.0], [10.2, 8.0], [10.3, 8.0], [10.4, 8.0], [10.5, 8.0], [10.6, 8.0], [10.7, 8.0], [10.8, 8.0], [10.9, 8.0], [11.0, 8.0], [11.1, 8.0], [11.2, 8.0], [11.3, 8.0], [11.4, 8.0], [11.5, 8.0], [11.6, 8.0], [11.7, 8.0], [11.8, 8.0], [11.9, 8.0], [12.0, 8.0], [12.1, 8.0], [12.2, 8.0], [12.3, 8.0], [12.4, 8.0], [12.5, 8.0], [12.6, 8.0], [12.7, 8.0], [12.8, 8.0], [12.9, 8.0], [13.0, 8.0], [13.1, 8.0], [13.2, 8.0], [13.3, 8.0], [13.4, 8.0], [13.5, 8.0], [13.6, 8.0], [13.7, 8.0], [13.8, 8.0], [13.9, 8.0], [14.0, 8.0], [14.1, 8.0], [14.2, 8.0], [14.3, 8.0], [14.4, 8.0], [14.5, 8.0], [14.6, 8.0], [14.7, 8.0], [14.8, 8.0], [14.9, 8.0], [15.0, 8.0], [15.1, 8.0], [15.2, 8.0], [15.3, 8.0], [15.4, 8.0], [15.5, 8.0], [15.6, 8.0], [15.7, 8.0], [15.8, 8.0], [15.9, 8.0], [16.0, 8.0], [16.1, 8.0], [16.2, 8.0], [16.3, 8.0], [16.4, 8.0], [16.5, 8.0], [16.6, 9.0], [16.7, 9.0], [16.8, 9.0], [16.9, 9.0], [17.0, 9.0], [17.1, 9.0], [17.2, 9.0], [17.3, 9.0], [17.4, 9.0], [17.5, 9.0], [17.6, 9.0], [17.7, 9.0], [17.8, 9.0], [17.9, 9.0], [18.0, 9.0], [18.1, 9.0], [18.2, 9.0], [18.3, 9.0], [18.4, 9.0], [18.5, 9.0], [18.6, 9.0], [18.7, 9.0], [18.8, 9.0], [18.9, 9.0], [19.0, 9.0], [19.1, 9.0], [19.2, 9.0], [19.3, 9.0], [19.4, 10.0], [19.5, 10.0], [19.6, 10.0], [19.7, 10.0], [19.8, 10.0], [19.9, 10.0], [20.0, 10.0], [20.1, 10.0], [20.2, 10.0], [20.3, 10.0], [20.4, 10.0], [20.5, 10.0], [20.6, 10.0], [20.7, 10.0], [20.8, 10.0], [20.9, 11.0], [21.0, 11.0], [21.1, 11.0], [21.2, 11.0], [21.3, 11.0], [21.4, 11.0], [21.5, 11.0], [21.6, 11.0], [21.7, 11.0], [21.8, 11.0], [21.9, 12.0], [22.0, 12.0], [22.1, 12.0], [22.2, 12.0], [22.3, 12.0], [22.4, 12.0], [22.5, 12.0], [22.6, 13.0], [22.7, 13.0], [22.8, 13.0], [22.9, 13.0], [23.0, 13.0], [23.1, 13.0], [23.2, 13.0], [23.3, 13.0], [23.4, 13.0], [23.5, 13.0], [23.6, 13.0], [23.7, 13.0], [23.8, 13.0], [23.9, 13.0], [24.0, 13.0], [24.1, 13.0], [24.2, 14.0], [24.3, 14.0], [24.4, 14.0], [24.5, 14.0], [24.6, 14.0], [24.7, 14.0], [24.8, 14.0], [24.9, 14.0], [25.0, 14.0], [25.1, 14.0], [25.2, 14.0], [25.3, 14.0], [25.4, 14.0], [25.5, 14.0], [25.6, 14.0], [25.7, 14.0], [25.8, 14.0], [25.9, 14.0], [26.0, 14.0], [26.1, 14.0], [26.2, 14.0], [26.3, 14.0], [26.4, 14.0], [26.5, 14.0], [26.6, 14.0], [26.7, 14.0], [26.8, 14.0], [26.9, 14.0], [27.0, 14.0], [27.1, 14.0], [27.2, 14.0], [27.3, 14.0], [27.4, 14.0], [27.5, 14.0], [27.6, 14.0], [27.7, 14.0], [27.8, 14.0], [27.9, 14.0], [28.0, 14.0], [28.1, 14.0], [28.2, 14.0], [28.3, 14.0], [28.4, 14.0], [28.5, 14.0], [28.6, 14.0], [28.7, 14.0], [28.8, 14.0], [28.9, 14.0], [29.0, 14.0], [29.1, 14.0], [29.2, 15.0], [29.3, 15.0], [29.4, 15.0], [29.5, 15.0], [29.6, 15.0], [29.7, 15.0], [29.8, 15.0], [29.9, 15.0], [30.0, 15.0], [30.1, 15.0], [30.2, 15.0], [30.3, 15.0], [30.4, 15.0], [30.5, 15.0], [30.6, 15.0], [30.7, 15.0], [30.8, 15.0], [30.9, 15.0], [31.0, 15.0], [31.1, 15.0], [31.2, 15.0], [31.3, 15.0], [31.4, 15.0], [31.5, 15.0], [31.6, 15.0], [31.7, 15.0], [31.8, 15.0], [31.9, 15.0], [32.0, 15.0], [32.1, 15.0], [32.2, 15.0], [32.3, 15.0], [32.4, 15.0], [32.5, 15.0], [32.6, 15.0], [32.7, 15.0], [32.8, 15.0], [32.9, 15.0], [33.0, 15.0], [33.1, 15.0], [33.2, 15.0], [33.3, 15.0], [33.4, 15.0], [33.5, 15.0], [33.6, 15.0], [33.7, 15.0], [33.8, 15.0], [33.9, 15.0], [34.0, 15.0], [34.1, 15.0], [34.2, 15.0], [34.3, 15.0], [34.4, 15.0], [34.5, 15.0], [34.6, 15.0], [34.7, 15.0], [34.8, 16.0], [34.9, 16.0], [35.0, 16.0], [35.1, 16.0], [35.2, 16.0], [35.3, 16.0], [35.4, 16.0], [35.5, 16.0], [35.6, 16.0], [35.7, 16.0], [35.8, 16.0], [35.9, 16.0], [36.0, 16.0], [36.1, 16.0], [36.2, 16.0], [36.3, 16.0], [36.4, 16.0], [36.5, 16.0], [36.6, 16.0], [36.7, 16.0], [36.8, 16.0], [36.9, 16.0], [37.0, 16.0], [37.1, 16.0], [37.2, 16.0], [37.3, 16.0], [37.4, 17.0], [37.5, 17.0], [37.6, 17.0], [37.7, 17.0], [37.8, 17.0], [37.9, 17.0], [38.0, 17.0], [38.1, 17.0], [38.2, 17.0], [38.3, 17.0], [38.4, 17.0], [38.5, 17.0], [38.6, 17.0], [38.7, 18.0], [38.8, 18.0], [38.9, 18.0], [39.0, 18.0], [39.1, 18.0], [39.2, 18.0], [39.3, 18.0], [39.4, 18.0], [39.5, 18.0], [39.6, 19.0], [39.7, 19.0], [39.8, 19.0], [39.9, 19.0], [40.0, 19.0], [40.1, 19.0], [40.2, 19.0], [40.3, 19.0], [40.4, 20.0], [40.5, 20.0], [40.6, 20.0], [40.7, 20.0], [40.8, 20.0], [40.9, 20.0], [41.0, 20.0], [41.1, 20.0], [41.2, 20.0], [41.3, 20.0], [41.4, 20.0], [41.5, 20.0], [41.6, 21.0], [41.7, 21.0], [41.8, 21.0], [41.9, 21.0], [42.0, 21.0], [42.1, 21.0], [42.2, 21.0], [42.3, 21.0], [42.4, 21.0], [42.5, 21.0], [42.6, 21.0], [42.7, 21.0], [42.8, 21.0], [42.9, 21.0], [43.0, 21.0], [43.1, 21.0], [43.2, 21.0], [43.3, 21.0], [43.4, 21.0], [43.5, 21.0], [43.6, 21.0], [43.7, 21.0], [43.8, 21.0], [43.9, 21.0], [44.0, 21.0], [44.1, 21.0], [44.2, 21.0], [44.3, 21.0], [44.4, 21.0], [44.5, 21.0], [44.6, 21.0], [44.7, 21.0], [44.8, 22.0], [44.9, 22.0], [45.0, 22.0], [45.1, 22.0], [45.2, 22.0], [45.3, 22.0], [45.4, 22.0], [45.5, 22.0], [45.6, 22.0], [45.7, 22.0], [45.8, 22.0], [45.9, 22.0], [46.0, 22.0], [46.1, 22.0], [46.2, 22.0], [46.3, 22.0], [46.4, 22.0], [46.5, 22.0], [46.6, 22.0], [46.7, 22.0], [46.8, 22.0], [46.9, 22.0], [47.0, 22.0], [47.1, 22.0], [47.2, 22.0], [47.3, 22.0], [47.4, 22.0], [47.5, 22.0], [47.6, 22.0], [47.7, 22.0], [47.8, 22.0], [47.9, 22.0], [48.0, 22.0], [48.1, 22.0], [48.2, 22.0], [48.3, 22.0], [48.4, 22.0], [48.5, 22.0], [48.6, 22.0], [48.7, 22.0], [48.8, 22.0], [48.9, 22.0], [49.0, 22.0], [49.1, 22.0], [49.2, 22.0], [49.3, 22.0], [49.4, 22.0], [49.5, 22.0], [49.6, 22.0], [49.7, 22.0], [49.8, 22.0], [49.9, 22.0], [50.0, 23.0], [50.1, 23.0], [50.2, 23.0], [50.3, 23.0], [50.4, 23.0], [50.5, 23.0], [50.6, 23.0], [50.7, 23.0], [50.8, 23.0], [50.9, 23.0], [51.0, 23.0], [51.1, 23.0], [51.2, 23.0], [51.3, 23.0], [51.4, 23.0], [51.5, 23.0], [51.6, 23.0], [51.7, 23.0], [51.8, 23.0], [51.9, 23.0], [52.0, 23.0], [52.1, 23.0], [52.2, 23.0], [52.3, 23.0], [52.4, 23.0], [52.5, 23.0], [52.6, 23.0], [52.7, 23.0], [52.8, 23.0], [52.9, 23.0], [53.0, 23.0], [53.1, 23.0], [53.2, 23.0], [53.3, 23.0], [53.4, 23.0], [53.5, 23.0], [53.6, 24.0], [53.7, 24.0], [53.8, 24.0], [53.9, 24.0], [54.0, 24.0], [54.1, 24.0], [54.2, 24.0], [54.3, 24.0], [54.4, 24.0], [54.5, 24.0], [54.6, 24.0], [54.7, 24.0], [54.8, 24.0], [54.9, 24.0], [55.0, 24.0], [55.1, 24.0], [55.2, 24.0], [55.3, 24.0], [55.4, 25.0], [55.5, 25.0], [55.6, 25.0], [55.7, 25.0], [55.8, 25.0], [55.9, 25.0], [56.0, 25.0], [56.1, 25.0], [56.2, 25.0], [56.3, 25.0], [56.4, 25.0], [56.5, 26.0], [56.6, 26.0], [56.7, 26.0], [56.8, 26.0], [56.9, 26.0], [57.0, 26.0], [57.1, 26.0], [57.2, 26.0], [57.3, 27.0], [57.4, 27.0], [57.5, 27.0], [57.6, 27.0], [57.7, 27.0], [57.8, 27.0], [57.9, 27.0], [58.0, 28.0], [58.1, 28.0], [58.2, 28.0], [58.3, 28.0], [58.4, 28.0], [58.5, 28.0], [58.6, 29.0], [58.7, 29.0], [58.8, 29.0], [58.9, 29.0], [59.0, 29.0], [59.1, 29.0], [59.2, 29.0], [59.3, 29.0], [59.4, 30.0], [59.5, 30.0], [59.6, 30.0], [59.7, 30.0], [59.8, 30.0], [59.9, 30.0], [60.0, 30.0], [60.1, 31.0], [60.2, 31.0], [60.3, 31.0], [60.4, 31.0], [60.5, 31.0], [60.6, 31.0], [60.7, 32.0], [60.8, 32.0], [60.9, 32.0], [61.0, 32.0], [61.1, 32.0], [61.2, 32.0], [61.3, 32.0], [61.4, 33.0], [61.5, 33.0], [61.6, 33.0], [61.7, 33.0], [61.8, 33.0], [61.9, 34.0], [62.0, 34.0], [62.1, 34.0], [62.2, 34.0], [62.3, 34.0], [62.4, 34.0], [62.5, 35.0], [62.6, 35.0], [62.7, 35.0], [62.8, 35.0], [62.9, 35.0], [63.0, 35.0], [63.1, 35.0], [63.2, 35.0], [63.3, 35.0], [63.4, 36.0], [63.5, 36.0], [63.6, 36.0], [63.7, 36.0], [63.8, 36.0], [63.9, 36.0], [64.0, 36.0], [64.1, 36.0], [64.2, 36.0], [64.3, 36.0], [64.4, 36.0], [64.5, 36.0], [64.6, 36.0], [64.7, 36.0], [64.8, 36.0], [64.9, 36.0], [65.0, 36.0], [65.1, 36.0], [65.2, 36.0], [65.3, 36.0], [65.4, 37.0], [65.5, 37.0], [65.6, 37.0], [65.7, 37.0], [65.8, 37.0], [65.9, 37.0], [66.0, 37.0], [66.1, 37.0], [66.2, 37.0], [66.3, 37.0], [66.4, 37.0], [66.5, 37.0], [66.6, 37.0], [66.7, 37.0], [66.8, 37.0], [66.9, 37.0], [67.0, 37.0], [67.1, 37.0], [67.2, 37.0], [67.3, 37.0], [67.4, 37.0], [67.5, 37.0], [67.6, 37.0], [67.7, 37.0], [67.8, 37.0], [67.9, 37.0], [68.0, 37.0], [68.1, 38.0], [68.2, 38.0], [68.3, 38.0], [68.4, 38.0], [68.5, 38.0], [68.6, 38.0], [68.7, 38.0], [68.8, 38.0], [68.9, 38.0], [69.0, 38.0], [69.1, 38.0], [69.2, 38.0], [69.3, 38.0], [69.4, 38.0], [69.5, 38.0], [69.6, 38.0], [69.7, 38.0], [69.8, 38.0], [69.9, 38.0], [70.0, 38.0], [70.1, 38.0], [70.2, 38.0], [70.3, 38.0], [70.4, 38.0], [70.5, 39.0], [70.6, 39.0], [70.7, 39.0], [70.8, 39.0], [70.9, 39.0], [71.0, 39.0], [71.1, 39.0], [71.2, 39.0], [71.3, 39.0], [71.4, 39.0], [71.5, 39.0], [71.6, 39.0], [71.7, 39.0], [71.8, 39.0], [71.9, 39.0], [72.0, 39.0], [72.1, 39.0], [72.2, 39.0], [72.3, 40.0], [72.4, 40.0], [72.5, 40.0], [72.6, 40.0], [72.7, 40.0], [72.8, 40.0], [72.9, 40.0], [73.0, 40.0], [73.1, 40.0], [73.2, 40.0], [73.3, 40.0], [73.4, 40.0], [73.5, 40.0], [73.6, 41.0], [73.7, 41.0], [73.8, 41.0], [73.9, 41.0], [74.0, 41.0], [74.1, 41.0], [74.2, 41.0], [74.3, 41.0], [74.4, 42.0], [74.5, 42.0], [74.6, 42.0], [74.7, 42.0], [74.8, 42.0], [74.9, 42.0], [75.0, 42.0], [75.1, 43.0], [75.2, 43.0], [75.3, 43.0], [75.4, 43.0], [75.5, 43.0], [75.6, 43.0], [75.7, 43.0], [75.8, 44.0], [75.9, 44.0], [76.0, 44.0], [76.1, 44.0], [76.2, 44.0], [76.3, 44.0], [76.4, 44.0], [76.5, 45.0], [76.6, 45.0], [76.7, 45.0], [76.8, 45.0], [76.9, 45.0], [77.0, 45.0], [77.1, 45.0], [77.2, 45.0], [77.3, 46.0], [77.4, 46.0], [77.5, 46.0], [77.6, 46.0], [77.7, 46.0], [77.8, 46.0], [77.9, 46.0], [78.0, 46.0], [78.1, 47.0], [78.2, 47.0], [78.3, 47.0], [78.4, 47.0], [78.5, 47.0], [78.6, 47.0], [78.7, 47.0], [78.8, 48.0], [78.9, 48.0], [79.0, 48.0], [79.1, 48.0], [79.2, 48.0], [79.3, 48.0], [79.4, 48.0], [79.5, 49.0], [79.6, 49.0], [79.7, 49.0], [79.8, 49.0], [79.9, 49.0], [80.0, 49.0], [80.1, 50.0], [80.2, 50.0], [80.3, 50.0], [80.4, 50.0], [80.5, 50.0], [80.6, 50.0], [80.7, 50.0], [80.8, 50.0], [80.9, 51.0], [81.0, 51.0], [81.1, 51.0], [81.2, 51.0], [81.3, 51.0], [81.4, 51.0], [81.5, 51.0], [81.6, 51.0], [81.7, 51.0], [81.8, 51.0], [81.9, 51.0], [82.0, 51.0], [82.1, 51.0], [82.2, 51.0], [82.3, 52.0], [82.4, 52.0], [82.5, 52.0], [82.6, 52.0], [82.7, 52.0], [82.8, 52.0], [82.9, 52.0], [83.0, 52.0], [83.1, 52.0], [83.2, 52.0], [83.3, 52.0], [83.4, 52.0], [83.5, 52.0], [83.6, 52.0], [83.7, 52.0], [83.8, 52.0], [83.9, 52.0], [84.0, 52.0], [84.1, 52.0], [84.2, 52.0], [84.3, 53.0], [84.4, 53.0], [84.5, 53.0], [84.6, 53.0], [84.7, 53.0], [84.8, 53.0], [84.9, 53.0], [85.0, 53.0], [85.1, 53.0], [85.2, 53.0], [85.3, 53.0], [85.4, 53.0], [85.5, 53.0], [85.6, 53.0], [85.7, 53.0], [85.8, 53.0], [85.9, 53.0], [86.0, 53.0], [86.1, 53.0], [86.2, 53.0], [86.3, 54.0], [86.4, 54.0], [86.5, 54.0], [86.6, 54.0], [86.7, 54.0], [86.8, 54.0], [86.9, 54.0], [87.0, 54.0], [87.1, 54.0], [87.2, 54.0], [87.3, 54.0], [87.4, 54.0], [87.5, 54.0], [87.6, 54.0], [87.7, 54.0], [87.8, 54.0], [87.9, 54.0], [88.0, 55.0], [88.1, 55.0], [88.2, 55.0], [88.3, 55.0], [88.4, 55.0], [88.5, 55.0], [88.6, 55.0], [88.7, 55.0], [88.8, 55.0], [88.9, 55.0], [89.0, 55.0], [89.1, 55.0], [89.2, 55.0], [89.3, 56.0], [89.4, 56.0], [89.5, 56.0], [89.6, 56.0], [89.7, 56.0], [89.8, 56.0], [89.9, 56.0], [90.0, 56.0], [90.1, 56.0], [90.2, 57.0], [90.3, 57.0], [90.4, 57.0], [90.5, 57.0], [90.6, 57.0], [90.7, 57.0], [90.8, 57.0], [90.9, 57.0], [91.0, 58.0], [91.1, 58.0], [91.2, 58.0], [91.3, 58.0], [91.4, 58.0], [91.5, 58.0], [91.6, 59.0], [91.7, 59.0], [91.8, 59.0], [91.9, 59.0], [92.0, 59.0], [92.1, 59.0], [92.2, 59.0], [92.3, 60.0], [92.4, 60.0], [92.5, 60.0], [92.6, 60.0], [92.7, 60.0], [92.8, 60.0], [92.9, 60.0], [93.0, 61.0], [93.1, 61.0], [93.2, 61.0], [93.3, 61.0], [93.4, 61.0], [93.5, 61.0], [93.6, 61.0], [93.7, 61.0], [93.8, 62.0], [93.9, 62.0], [94.0, 62.0], [94.1, 62.0], [94.2, 62.0], [94.3, 62.0], [94.4, 62.0], [94.5, 63.0], [94.6, 63.0], [94.7, 63.0], [94.8, 63.0], [94.9, 63.0], [95.0, 63.0], [95.1, 64.0], [95.2, 64.0], [95.3, 64.0], [95.4, 64.0], [95.5, 64.0], [95.6, 64.0], [95.7, 65.0], [95.8, 65.0], [95.9, 65.0], [96.0, 65.0], [96.1, 65.0], [96.2, 66.0], [96.3, 66.0], [96.4, 66.0], [96.5, 66.0], [96.6, 67.0], [96.7, 67.0], [96.8, 67.0], [96.9, 67.0], [97.0, 68.0], [97.1, 68.0], [97.2, 68.0], [97.3, 69.0], [97.4, 69.0], [97.5, 70.0], [97.6, 70.0], [97.7, 71.0], [97.8, 71.0], [97.9, 72.0], [98.0, 73.0], [98.1, 74.0], [98.2, 75.0], [98.3, 75.0], [98.4, 76.0], [98.5, 78.0], [98.6, 79.0], [98.7, 80.0], [98.8, 82.0], [98.9, 85.0], [99.0, 89.0], [99.1, 93.0], [99.2, 96.0], [99.3, 98.0], [99.4, 102.0], [99.5, 104.0], [99.6, 107.0], [99.7, 110.0], [99.8, 115.0], [99.9, 125.0]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 527546.0, "series": [{"data": [[0.0, 527546.0], [300.0, 1.0], [1300.0, 30.0], [100.0, 3506.0], [200.0, 8.0]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 30.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 531061.0, "series": [{"data": [[0.0, 531061.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 30.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 6.2770891643342495, "minX": 1.79399754E12, "maxY": 20.0, "series": [{"data": [[1.79399778E12, 10.0], [1.7939976E12, 10.0], [1.79399766E12, 10.0], [1.79399796E12, 9.993600682593858], [1.79399754E12, 9.167784022934011], [1.79399784E12, 10.0], [1.7939979E12, 10.0], [1.79399772E12, 10.0]], "isOverall": false, "label": "Gradino 1", "isController": false}, {"data": [[1.79399778E12, 10.0], [1.79399796E12, 9.993635077793494], [1.79399784E12, 10.0], [1.7939979E12, 10.0], [1.79399772E12, 9.036621557454867]], "isOverall": false, "label": "Gradino 3", "isController": false}, {"data": [[1.79399778E12, 10.0], [1.7939976E12, 6.2770891643342495], [1.79399766E12, 10.0], [1.79399796E12, 9.993769470404985], [1.79399784E12, 10.0], [1.7939979E12, 10.0], [1.79399772E12, 10.0]], "isOverall": false, "label": "Gradino 2", "isController": false}, {"data": [[1.79399796E12, 19.98693552967907], [1.7939979E12, 18.067411653726182]], "isOverall": false, "label": "Gradino 5", "isController": false}, {"data": [[1.79399778E12, 12.360222016651242], [1.79399796E12, 19.986760623531925], [1.79399784E12, 19.998289345063622], [1.7939979E12, 20.0]], "isOverall": false, "label": "Gradino 4", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399796E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 7.135, "minX": 1.0, "maxY": 58.56769947059953, "series": [{"data": [[2.0, 8.4304347826087], [3.0, 7.135], [4.0, 7.4636275460717725], [5.0, 8.02315963606287], [6.0, 8.62536023054756], [7.0, 9.997090909090906], [8.0, 10.69037940379403], [9.0, 10.059293044469792], [10.0, 8.299533240527422], [11.0, 8.971830985915474], [12.0, 9.550620248099202], [13.0, 10.163305654408857], [14.0, 11.148790322580654], [15.0, 11.756385068762286], [16.0, 13.011503697617087], [17.0, 13.684975767366693], [18.0, 14.651067323481147], [19.0, 15.170898831116483], [20.0, 16.066446377593294], [21.0, 17.197869725522327], [22.0, 18.141376451077956], [23.0, 18.31069131832797], [24.0, 19.339105920257726], [25.0, 19.964285714285758], [26.0, 21.37680561287658], [27.0, 22.340133222314716], [28.0, 23.019413465510073], [29.0, 23.469130787977267], [30.0, 24.74248057553922], [31.0, 26.087140439932313], [32.0, 25.596967278531544], [33.0, 26.268704746580877], [34.0, 27.329600000000003], [35.0, 28.14963797264685], [36.0, 28.668820678513733], [37.0, 29.935691318328015], [38.0, 30.745542949756853], [39.0, 30.737509912767678], [40.0, 31.117462803445612], [41.0, 34.90067911714773], [42.0, 34.695222405271885], [43.0, 37.30446194225719], [44.0, 35.52960259529612], [45.0, 38.66809974204644], [46.0, 36.837620578778115], [47.0, 39.05499999999996], [48.0, 38.649476228847696], [49.0, 40.48120300751883], [50.0, 41.62241239464464], [51.0, 42.97700170357751], [52.0, 43.078333333333376], [53.0, 46.42881944444443], [54.0, 44.58684654300163], [55.0, 46.40283569641367], [56.0, 46.57558139534881], [57.0, 46.02672064777315], [58.0, 47.997516556291444], [59.0, 48.39571310799672], [60.0, 48.05113636363639], [61.0, 53.29192006950476], [62.0, 51.90591174021654], [63.0, 50.15255591054316], [64.0, 54.6598114824335], [65.0, 53.29440789473686], [66.0, 54.96982397317689], [67.0, 55.37336601307187], [68.0, 54.851701782820086], [69.0, 55.37341772151891], [70.0, 58.56769947059953], [1.0, 16.758928571428577]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}, {"data": [[35.14627436729288, 29.158631948197588]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 70.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 107060.75, "minX": 1.79399754E12, "maxY": 2455073.683333333, "series": [{"data": [[1.79399778E12, 2385596.933333333], [1.7939976E12, 2455073.683333333], [1.79399766E12, 2452457.816666667], [1.79399796E12, 1631852.85], [1.79399754E12, 1466471.25], [1.79399784E12, 2375128.466666667], [1.7939979E12, 2374435.216666667], [1.79399772E12, 2439382.9166666665]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79399778E12, 174161.91666666666], [1.7939976E12, 179234.5], [1.79399766E12, 179043.58333333334], [1.79399796E12, 119134.41666666667], [1.79399754E12, 107060.75], [1.79399784E12, 173398.25], [1.7939979E12, 173347.5], [1.79399772E12, 178089.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399796E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 8.834969865240026, "minX": 1.79399754E12, "maxY": 58.39150455402952, "series": [{"data": [[1.79399778E12, 27.44415613248773], [1.7939976E12, 9.302173502683228], [1.79399766E12, 16.07666662167463], [1.79399796E12, 58.39150455402952], [1.79399754E12, 8.834969865240026], [1.79399784E12, 41.68298699669642], [1.7939979E12, 52.65342255680965], [1.79399772E12, 21.57007544916688]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399796E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 8.830319857339509, "minX": 1.79399754E12, "maxY": 58.38817777958065, "series": [{"data": [[1.79399778E12, 27.441325433277562], [1.7939976E12, 9.299085834479364], [1.79399766E12, 16.073629651625605], [1.79399796E12, 58.38817777958065], [1.79399754E12, 8.830319857339509], [1.79399784E12, 41.67946091343676], [1.7939979E12, 52.650118499929995], [1.79399772E12, 21.566764370623797]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399796E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.009736900825608023, "minX": 1.79399754E12, "maxY": 0.011737884020676647, "series": [{"data": [[1.79399778E12, 0.009976827119208567], [1.7939976E12, 0.010072000647196738], [1.79399766E12, 0.009812787668551823], [1.79399796E12, 0.009736900825608023], [1.79399754E12, 0.011737884020676647], [1.79399784E12, 0.01004864043706707], [1.7939979E12, 0.010051582322598606], [1.79399772E12, 0.010001085599522265]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399796E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.79399754E12, "maxY": 1363.0, "series": [{"data": [[1.79399778E12, 1363.0], [1.7939976E12, 52.0], [1.79399766E12, 55.0], [1.79399796E12, 267.0], [1.79399754E12, 347.0], [1.79399784E12, 172.0], [1.7939979E12, 229.0], [1.79399772E12, 97.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79399778E12, 6.0], [1.7939976E12, 5.0], [1.79399766E12, 6.0], [1.79399796E12, 6.0], [1.79399754E12, 5.0], [1.79399784E12, 6.0], [1.7939979E12, 6.0], [1.79399772E12, 6.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79399778E12, 45.0], [1.7939976E12, 17.0], [1.79399766E12, 22.0], [1.79399796E12, 72.0], [1.79399754E12, 10.0], [1.79399784E12, 51.0], [1.7939979E12, 69.0], [1.79399772E12, 32.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79399778E12, 67.0], [1.7939976E12, 25.0], [1.79399766E12, 31.0], [1.79399796E12, 115.0], [1.79399754E12, 21.0], [1.79399784E12, 79.0], [1.7939979E12, 117.0], [1.79399772E12, 46.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79399778E12, 33.0], [1.7939976E12, 12.0], [1.79399766E12, 15.0], [1.79399796E12, 56.0], [1.79399754E12, 7.0], [1.79399784E12, 39.0], [1.7939979E12, 56.0], [1.79399772E12, 23.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79399778E12, 50.0], [1.7939976E12, 21.0], [1.79399766E12, 24.0], [1.79399796E12, 91.0], [1.79399754E12, 14.0], [1.79399784E12, 59.0], [1.7939979E12, 79.0], [1.79399772E12, 36.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399796E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 7.0, "minX": 21.0, "maxY": 70.0, "series": [{"data": [[21.0, 21.0], [81.0, 12.0], [187.0, 9.0], [226.0, 70.0], [240.0, 7.0], [371.0, 7.0], [414.0, 7.0], [508.0, 7.0], [512.0, 7.0], [576.0, 8.0], [610.0, 8.0], [639.0, 11.0], [670.0, 8.0], [663.0, 10.0], [708.0, 8.0], [736.0, 9.0], [806.0, 9.0], [861.0, 9.0], [865.0, 9.0], [871.0, 10.0], [872.0, 22.0], [916.0, 10.0], [945.0, 10.0], [936.0, 9.0], [983.0, 9.0], [991.0, 9.0], [1038.0, 9.0], [1041.0, 9.0], [1040.0, 9.0], [1085.0, 16.0], [1056.0, 43.0], [1024.0, 46.0], [1076.0, 42.0], [1046.0, 62.0], [1068.0, 59.0], [1141.0, 14.0], [1138.0, 8.0], [1103.0, 58.0], [1139.0, 53.0], [1108.0, 8.0], [1093.0, 8.0], [1151.0, 37.0], [1120.0, 15.0], [1135.0, 41.0], [1133.0, 60.0], [1142.0, 16.0], [1145.0, 54.0], [1143.0, 59.0], [1147.0, 51.5], [1148.0, 50.0], [1149.0, 60.0], [1146.0, 53.0], [1111.0, 42.0], [1091.0, 58.0], [1116.0, 58.0], [1109.0, 42.0], [1212.0, 24.0], [1164.0, 8.0], [1153.0, 15.0], [1208.0, 35.0], [1210.0, 22.0], [1211.0, 23.0], [1209.0, 16.0], [1213.0, 15.0], [1214.0, 31.0], [1183.0, 33.0], [1152.0, 40.0], [1180.0, 37.0], [1178.0, 57.0], [1176.0, 40.0], [1174.0, 41.0], [1175.0, 39.0], [1172.0, 33.0], [1171.0, 34.0], [1169.0, 46.0], [1173.0, 40.0], [1182.0, 39.0], [1207.0, 38.0], [1204.0, 7.0], [1202.0, 21.0], [1203.0, 56.0], [1201.0, 22.0], [1200.0, 23.0], [1166.0, 52.0], [1165.0, 58.0], [1186.0, 33.0], [1185.0, 40.0], [1187.0, 37.0], [1190.0, 39.0], [1189.0, 53.0], [1191.0, 23.0], [1188.0, 51.0], [1196.0, 28.0], [1193.0, 37.0], [1194.0, 40.0], [1197.0, 38.0], [1198.0, 36.0], [1199.0, 45.0], [1192.0, 24.0], [1215.0, 23.0], [1162.0, 8.0], [1157.0, 40.0], [1154.0, 41.0], [1160.0, 41.0], [1163.0, 48.0], [1206.0, 15.0], [1205.0, 56.0], [1228.0, 22.0], [1260.0, 16.0], [1254.0, 22.0], [1253.0, 15.0], [1258.0, 15.0], [1257.0, 21.0], [1255.0, 34.0], [1256.0, 27.0], [1259.0, 15.0], [1261.0, 10.0], [1262.0, 14.0], [1242.0, 15.0], [1247.0, 23.0], [1244.0, 14.0], [1243.0, 36.0], [1246.0, 23.0], [1245.0, 37.5], [1252.0, 22.0], [1231.0, 9.0], [1279.0, 14.0], [1264.0, 13.0], [1265.0, 23.0], [1267.0, 15.0], [1266.0, 22.0], [1275.0, 14.0], [1276.0, 22.0], [1278.0, 30.0], [1274.0, 15.0], [1271.0, 23.0], [1270.0, 22.0], [1268.0, 15.0], [1248.0, 21.0], [1249.0, 41.0], [1250.0, 7.0], [1251.0, 22.0], [1229.0, 14.0], [1230.0, 21.0], [1238.0, 23.0], [1239.0, 17.0], [1240.0, 22.0], [1241.0, 23.0], [1235.0, 19.0], [1234.0, 23.0], [1232.0, 34.0], [1233.0, 35.0], [1236.0, 37.0], [1237.0, 16.0], [1225.0, 11.0], [1216.0, 52.0], [1218.0, 24.0], [1219.0, 36.0], [1217.0, 23.0], [1220.0, 24.0], [1221.0, 17.0], [1222.0, 24.0], [1224.0, 38.0], [1223.0, 36.0], [1227.0, 15.0], [1226.0, 35.0], [1286.0, 7.0], [1280.0, 7.0], [1295.0, 7.0], [1294.0, 15.0], [1281.0, 15.0], [1296.0, 15.0], [1285.0, 15.0], [1284.0, 15.0], [1297.0, 15.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1297.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 6.0, "minX": 21.0, "maxY": 70.0, "series": [{"data": [[21.0, 21.0], [81.0, 12.0], [187.0, 9.0], [226.0, 70.0], [240.0, 7.0], [371.0, 7.0], [414.0, 6.0], [508.0, 7.0], [512.0, 7.0], [576.0, 8.0], [610.0, 8.0], [639.0, 11.0], [670.0, 8.0], [663.0, 10.0], [708.0, 8.0], [736.0, 9.0], [806.0, 9.0], [861.0, 9.0], [865.0, 9.0], [871.0, 10.0], [872.0, 22.0], [916.0, 10.0], [945.0, 10.0], [936.0, 9.0], [983.0, 9.0], [991.0, 9.0], [1038.0, 9.0], [1041.0, 9.0], [1040.0, 9.0], [1085.0, 16.0], [1056.0, 43.0], [1024.0, 46.0], [1076.0, 42.0], [1046.0, 62.0], [1068.0, 59.0], [1141.0, 14.0], [1138.0, 8.0], [1103.0, 58.0], [1139.0, 53.0], [1108.0, 8.0], [1093.0, 8.0], [1151.0, 37.0], [1120.0, 15.0], [1135.0, 41.0], [1133.0, 60.0], [1142.0, 16.0], [1145.0, 54.0], [1143.0, 59.0], [1147.0, 51.5], [1148.0, 50.0], [1149.0, 60.0], [1146.0, 53.0], [1111.0, 42.0], [1091.0, 58.0], [1116.0, 58.0], [1109.0, 42.0], [1212.0, 24.0], [1164.0, 8.0], [1153.0, 15.0], [1208.0, 35.0], [1210.0, 22.0], [1211.0, 23.0], [1209.0, 16.0], [1213.0, 15.0], [1214.0, 31.0], [1183.0, 33.0], [1152.0, 40.0], [1180.0, 37.0], [1178.0, 57.0], [1176.0, 40.0], [1174.0, 41.0], [1175.0, 39.0], [1172.0, 33.0], [1171.0, 34.0], [1169.0, 46.0], [1173.0, 40.0], [1182.0, 39.0], [1207.0, 38.0], [1204.0, 7.0], [1202.0, 21.0], [1203.0, 56.0], [1201.0, 22.0], [1200.0, 23.0], [1166.0, 52.0], [1165.0, 58.0], [1186.0, 33.0], [1185.0, 40.0], [1187.0, 37.0], [1190.0, 39.0], [1189.0, 53.0], [1191.0, 23.0], [1188.0, 51.0], [1196.0, 28.0], [1193.0, 37.0], [1194.0, 40.0], [1197.0, 38.0], [1198.0, 36.0], [1199.0, 45.0], [1192.0, 24.0], [1215.0, 23.0], [1162.0, 8.0], [1157.0, 40.0], [1154.0, 41.0], [1160.0, 41.0], [1163.0, 48.0], [1206.0, 15.0], [1205.0, 56.0], [1228.0, 22.0], [1260.0, 16.0], [1254.0, 22.0], [1253.0, 15.0], [1258.0, 15.0], [1257.0, 21.0], [1255.0, 34.0], [1256.0, 27.0], [1259.0, 15.0], [1261.0, 10.0], [1262.0, 14.0], [1242.0, 15.0], [1247.0, 23.0], [1244.0, 14.0], [1243.0, 36.0], [1246.0, 23.0], [1245.0, 37.5], [1252.0, 22.0], [1231.0, 9.0], [1279.0, 14.0], [1264.0, 13.0], [1265.0, 23.0], [1267.0, 15.0], [1266.0, 22.0], [1275.0, 14.0], [1276.0, 22.0], [1278.0, 30.0], [1274.0, 15.0], [1271.0, 23.0], [1270.0, 22.0], [1268.0, 15.0], [1248.0, 21.0], [1249.0, 41.0], [1250.0, 7.0], [1251.0, 22.0], [1229.0, 14.0], [1230.0, 21.0], [1238.0, 23.0], [1239.0, 17.0], [1240.0, 22.0], [1241.0, 23.0], [1235.0, 19.0], [1234.0, 23.0], [1232.0, 34.0], [1233.0, 35.0], [1236.0, 37.0], [1237.0, 16.0], [1225.0, 11.0], [1216.0, 52.0], [1218.0, 24.0], [1219.0, 36.0], [1217.0, 23.0], [1220.0, 24.0], [1221.0, 17.0], [1222.0, 24.0], [1224.0, 38.0], [1223.0, 36.0], [1227.0, 15.0], [1226.0, 35.0], [1286.0, 7.0], [1280.0, 7.0], [1295.0, 7.0], [1294.0, 15.0], [1281.0, 15.0], [1296.0, 15.0], [1285.0, 15.0], [1284.0, 15.0], [1297.0, 15.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1297.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 738.4833333333333, "minX": 1.79399754E12, "maxY": 1236.3, "series": [{"data": [[1.79399778E12, 1201.4], [1.7939976E12, 1236.3], [1.79399766E12, 1234.7833333333333], [1.79399796E12, 820.45], [1.79399754E12, 738.4833333333333], [1.79399784E12, 1195.8833333333334], [1.7939979E12, 1195.85], [1.79399772E12, 1228.3666666666666]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399796E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 738.35, "minX": 1.79399754E12, "maxY": 1236.1, "series": [{"data": [[1.79399778E12, 1201.1166666666666], [1.7939976E12, 1236.1], [1.79399766E12, 1234.7833333333333], [1.79399796E12, 821.6166666666667], [1.79399754E12, 738.35], [1.79399784E12, 1195.85], [1.7939979E12, 1195.5], [1.79399772E12, 1228.2]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79399796E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 738.35, "minX": 1.79399754E12, "maxY": 1236.1, "series": [{"data": [[1.79399778E12, 1201.1166666666666], [1.7939976E12, 1236.1], [1.79399766E12, 1234.7833333333333], [1.79399796E12, 821.6166666666667], [1.79399754E12, 738.35], [1.79399784E12, 1195.85], [1.7939979E12, 1195.5], [1.79399772E12, 1228.2]], "isOverall": false, "label": "GET /api/resume/resume-pdf/{id}-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399796E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 738.35, "minX": 1.79399754E12, "maxY": 1236.1, "series": [{"data": [[1.79399778E12, 1201.1166666666666], [1.7939976E12, 1236.1], [1.79399766E12, 1234.7833333333333], [1.79399796E12, 821.6166666666667], [1.79399754E12, 738.35], [1.79399784E12, 1195.85], [1.7939979E12, 1195.5], [1.79399772E12, 1228.2]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79399796E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

