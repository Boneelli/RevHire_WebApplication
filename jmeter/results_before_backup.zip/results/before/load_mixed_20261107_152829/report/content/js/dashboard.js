/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /applications/seeker/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/jobs/search?title=java"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/employer/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/update-status/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/jobseeker/favorites/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs/get/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/register"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/submit-application"], "isController": false}, {"data": [1.0, 500, 1500, "GET /employer/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (seeker)"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/jobseeker/favorites/{userId}/{jobId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (employer)"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/resume/resume-pdf/{id}"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21744, 0, 0.0, 9.019407652685807, 0, 316, 4.0, 22.0, 38.0, 59.9900000000016, 60.72267354022905, 675.9105312788862, 12.004087868311332], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /applications/seeker/{seekerId}", 1091, 0, 0.0, 10.501374885426218, 1, 43, 9.0, 18.0, 21.0, 26.0, 3.112269931649874, 5.320358454833575, 0.5957079166048587], "isController": false}, {"data": ["GET /jobs", 1290, 0, 0.0, 9.270542635658918, 3, 50, 9.0, 14.0, 16.0, 22.0, 3.691557493861713, 57.121805166248855, 0.6344864442574818], "isController": false}, {"data": ["GET /jobseeker/jobs/search?title=java", 4362, 0, 0.0, 3.773498395231541, 1, 57, 3.0, 6.0, 7.0, 10.0, 12.289435649505972, 357.85780487985255, 2.4482860083000175], "isController": false}, {"data": ["GET /applications/employer/{userId}", 2047, 0, 0.0, 36.65803615046403, 9, 115, 35.0, 53.0, 57.0, 64.51999999999998, 5.792188609733254, 67.61815829553461, 1.119973969460141], "isController": false}, {"data": ["POST /applications/update-status/{id}", 185, 0, 0.0, 7.5351351351351346, 2, 50, 7.0, 12.0, 13.699999999999989, 25.919999999999618, 0.5349047002220577, 0.10499594213343126, 0.1608893043636658], "isController": false}, {"data": ["GET /api/jobseeker/favorites/{seekerId}", 441, 0, 0.0, 9.714285714285712, 1, 36, 8.0, 17.0, 19.0, 25.579999999999984, 1.2945876840971207, 2.2651356996130914, 0.2528491570502188], "isController": false}, {"data": ["GET /jobs/get/{id}", 4336, 0, 0.0, 2.2601476014760107, 0, 56, 2.0, 4.0, 5.0, 7.0, 12.28899545397862, 4.129521775874627, 2.220179842759809], "isController": false}, {"data": ["GET /jobseeker/dashboard/{userId}", 4382, 0, 0.0, 3.4436330442720258, 1, 232, 3.0, 6.0, 7.0, 10.170000000000073, 12.295311956363147, 128.8966541519125, 2.3533995541476336], "isController": false}, {"data": ["POST /auth/register", 136, 0, 0.0, 95.44117647058826, 72, 120, 99.0, 107.0, 108.0, 117.03999999999996, 0.40099895917181916, 0.07440410375258363, 0.17308744136127352], "isController": false}, {"data": ["POST /applications/submit-application", 442, 0, 0.0, 10.972850678733046, 3, 55, 10.0, 18.0, 20.0, 26.569999999999993, 1.2602789721598102, 0.24122527201496366, 0.438143861414934], "isController": false}, {"data": ["GET /employer/dashboard/{userId}", 2056, 0, 0.0, 6.894941634241245, 2, 56, 6.0, 12.0, 13.0, 19.0, 5.7949609770259105, 56.376591363824055, 1.103532607929739], "isController": false}, {"data": ["POST /auth/login (seeker)", 80, 0, 0.0, 92.17499999999998, 72, 135, 91.0, 111.9, 116.95, 135.0, 1.3607293509320995, 0.42921443393659, 0.3623406989896584], "isController": false}, {"data": ["POST /api/jobseeker/favorites/{userId}/{jobId}", 444, 0, 0.0, 7.141891891891892, 2, 55, 6.0, 12.0, 13.0, 18.650000000000034, 1.2963882157143274, 0.3215650456947648, 0.3658751897865631], "isController": false}, {"data": ["POST /auth/login (employer)", 20, 0, 0.0, 94.5, 74, 108, 96.5, 107.0, 107.95, 108.0, 0.34815910871268174, 0.10947971973191749, 0.09145976586299939], "isController": false}, {"data": ["GET /api/resume/resume-pdf/{id}", 432, 0, 0.0, 14.33796296296297, 3, 316, 13.0, 20.69999999999999, 22.0, 38.01000000000005, 1.2750885478158205, 2.4725507535788074, 0.24655032467532467], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21744, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
