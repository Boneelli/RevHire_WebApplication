/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/seeker/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/jobs/search?title=java"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/employer/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/update-status/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/jobseeker/favorites/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs/get/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/submit-application"], "isController": false}, {"data": [1.0, 500, 1500, "GET /employer/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (seeker)"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/jobseeker/favorites/{userId}/{jobId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (employer)"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/resume/resume-pdf/{id}"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 59007, 0, 0.0, 5.483400274543725, 0, 260, 2.0, 10.0, 27.0, 39.0, 236.22737590526404, 2746.346185711991, 45.42649230325395], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /jobs", 3847, 0, 0.0, 6.521445282037956, 3, 38, 6.0, 10.0, 11.0, 19.0, 15.473599954950789, 239.42904491396405, 2.659524992257167], "isController": false}, {"data": ["GET /applications/seeker/{seekerId}", 3206, 0, 0.0, 7.244541484716156, 2, 39, 7.0, 11.0, 13.0, 20.0, 12.934721213588315, 21.037483199941498, 2.4757864822883886], "isController": false}, {"data": ["GET /jobseeker/jobs/search?title=java", 12771, 0, 0.0, 2.1085271317829344, 1, 37, 2.0, 3.0, 4.0, 10.0, 51.280300992198136, 1493.2264693622185, 10.215997463289472], "isController": false}, {"data": ["GET /applications/employer/{userId}", 5323, 0, 0.0, 30.27954161187302, 8, 95, 28.0, 44.0, 50.0, 61.0, 21.43363344983652, 225.05772047942804, 4.144393967839483], "isController": false}, {"data": ["POST /applications/update-status/{id}", 523, 0, 0.0, 4.502868068833652, 1, 16, 4.0, 7.0, 8.0, 10.759999999999991, 2.1216263909228466, 0.41587762769310654, 0.6381454378947625], "isController": false}, {"data": ["GET /api/jobseeker/favorites/{seekerId}", 362, 0, 0.0, 5.908839779005525, 1, 19, 5.0, 10.0, 11.0, 15.0, 1.4947806553911205, 2.283850381540698, 0.29194934675607825], "isController": false}, {"data": ["GET /jobs/get/{id}", 12755, 0, 0.0, 1.343237945903574, 0, 38, 1.0, 2.0, 3.0, 7.0, 51.26360464929344, 17.21385100120774, 9.261491074335241], "isController": false}, {"data": ["GET /jobseeker/dashboard/{userId}", 12782, 0, 0.0, 2.0722891566265096, 0, 182, 2.0, 3.0, 4.0, 9.0, 51.247098256347755, 537.2284211946062, 9.809014900629062], "isController": false}, {"data": ["POST /applications/submit-application", 398, 0, 0.0, 7.522613065326638, 3, 29, 7.0, 11.0, 13.0, 17.00999999999999, 1.6068667309951674, 0.3068783005365643, 0.5586372619475386], "isController": false}, {"data": ["GET /employer/dashboard/{userId}", 5332, 0, 0.0, 3.965678919729944, 2, 30, 4.0, 6.0, 7.0, 10.0, 21.440864711843144, 208.580377262158, 4.082977166806067], "isController": false}, {"data": ["POST /auth/login (seeker)", 40, 0, 0.0, 79.65000000000002, 74, 126, 77.0, 86.69999999999999, 107.04999999999993, 126.0, 4.16579879191835, 1.3140166111226828, 1.1091846099770881], "isController": false}, {"data": ["POST /api/jobseeker/favorites/{userId}/{jobId}", 362, 0, 0.0, 4.643646408839779, 2, 24, 4.0, 6.0, 8.0, 13.0, 1.4947065915734883, 0.3705234285967926, 0.4218459032858771], "isController": false}, {"data": ["POST /auth/login (employer)", 10, 0, 0.0, 77.6, 75, 81, 77.5, 80.9, 81.0, 81.0, 1.1049723756906078, 0.3474620165745856, 0.2902710635359116], "isController": false}, {"data": ["GET /api/resume/resume-pdf/{id}", 1296, 0, 0.0, 7.131172839506178, 3, 260, 6.0, 10.0, 12.0, 18.029999999999973, 5.256625538439074, 10.183258302963747, 1.016417828721618], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 59007, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
