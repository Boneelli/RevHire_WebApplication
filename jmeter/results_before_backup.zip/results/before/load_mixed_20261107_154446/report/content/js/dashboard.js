/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/seeker/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/jobs/search?title=java"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/employer/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/jobseeker/favorites/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/update-status/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs/get/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/register"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/submit-application"], "isController": false}, {"data": [1.0, 500, 1500, "GET /employer/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (seeker)"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/jobseeker/favorites/{userId}/{jobId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (employer)"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/resume/resume-pdf/{id}"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21824, 0, 0.0, 8.802648460410609, 0, 312, 4.0, 21.0, 36.0, 57.0, 60.793965173838316, 672.9964243170986, 12.005600935489982], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /jobs", 1292, 0, 0.0, 9.506965944272444, 3, 51, 9.0, 15.0, 17.0, 24.069999999999936, 3.6545386144999195, 56.54898861987424, 0.6281238243671736], "isController": false}, {"data": ["GET /applications/seeker/{seekerId}", 1097, 0, 0.0, 9.64813126709208, 2, 51, 9.0, 16.0, 19.0, 24.0, 3.157952311177769, 5.023242714327661, 0.6044518095613699], "isController": false}, {"data": ["GET /jobseeker/jobs/search?title=java", 4389, 0, 0.0, 3.7400318979266363, 1, 87, 3.0, 6.0, 7.0, 11.0, 12.362126657578386, 359.97450456608624, 2.462767420064444], "isController": false}, {"data": ["GET /applications/employer/{userId}", 2035, 0, 0.0, 35.470270270270305, 10, 95, 34.0, 52.0, 56.0, 64.0, 5.766375372618359, 63.768758097896615, 1.114982738064878], "isController": false}, {"data": ["GET /api/jobseeker/favorites/{seekerId}", 434, 0, 0.0, 9.921658986175117, 2, 48, 9.0, 17.0, 20.25, 28.949999999999932, 1.2470798504653562, 2.2044794303661073, 0.2435702832940149], "isController": false}, {"data": ["POST /applications/update-status/{id}", 213, 0, 0.0, 7.816901408450703, 2, 30, 7.0, 13.0, 16.599999999999966, 27.43999999999994, 0.6107176649367778, 0.11987719790262924, 0.18369242265676522], "isController": false}, {"data": ["GET /jobs/get/{id}", 4364, 0, 0.0, 2.2422089825847924, 0, 41, 2.0, 4.0, 5.0, 7.350000000000364, 12.354801357782478, 4.1513727915863345, 2.2320686046774982], "isController": false}, {"data": ["GET /jobseeker/dashboard/{userId}", 4411, 0, 0.0, 3.4450238041260515, 1, 197, 3.0, 6.0, 7.0, 11.0, 12.363603748041472, 129.6125842140871, 2.366471029898563], "isController": false}, {"data": ["POST /auth/register", 126, 0, 0.0, 97.1984126984127, 73, 114, 100.5, 108.0, 110.0, 113.46000000000001, 0.38538827869078096, 0.07150759077270351, 0.1663492374817629], "isController": false}, {"data": ["POST /applications/submit-application", 418, 0, 0.0, 10.806220095693792, 4, 30, 10.0, 18.0, 20.0, 25.0, 1.205170122160426, 0.23067709369476905, 0.4189849252823356], "isController": false}, {"data": ["GET /employer/dashboard/{userId}", 2044, 0, 0.0, 6.9584148727984365, 2, 66, 6.0, 12.0, 14.0, 21.549999999999955, 5.766762121062507, 56.10268837989674, 1.0981627086007701], "isController": false}, {"data": ["POST /auth/login (seeker)", 80, 0, 0.0, 93.9, 72, 137, 93.0, 111.9, 115.9, 137.0, 1.3478678415581353, 0.4251575320539821, 0.3588336151921554], "isController": false}, {"data": ["POST /api/jobseeker/favorites/{userId}/{jobId}", 435, 0, 0.0, 7.1540229885057505, 2, 42, 6.0, 12.0, 13.0, 18.0, 1.243095106777583, 0.30834585656397084, 0.35083445884640774], "isController": false}, {"data": ["POST /auth/login (employer)", 20, 0, 0.0, 92.1, 73, 119, 89.0, 108.80000000000001, 118.5, 119.0, 0.34852313322296763, 0.10959418837675351, 0.09155539339548663], "isController": false}, {"data": ["GET /api/resume/resume-pdf/{id}", 466, 0, 0.0, 13.390557939914164, 4, 312, 12.0, 20.0, 23.0, 33.0, 1.3470388270934026, 2.6108672709672662, 0.26046258570751335], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21824, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
