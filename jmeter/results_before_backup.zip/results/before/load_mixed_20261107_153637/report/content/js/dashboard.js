/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/seeker/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/jobs/search?title=java"], "isController": false}, {"data": [1.0, 500, 1500, "GET /applications/employer/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/jobseeker/favorites/{seekerId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/update-status/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobs/get/{id}"], "isController": false}, {"data": [1.0, 500, 1500, "GET /jobseeker/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/register"], "isController": false}, {"data": [1.0, 500, 1500, "POST /applications/submit-application"], "isController": false}, {"data": [1.0, 500, 1500, "GET /employer/dashboard/{userId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (seeker)"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/jobseeker/favorites/{userId}/{jobId}"], "isController": false}, {"data": [1.0, 500, 1500, "POST /auth/login (employer)"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/resume/resume-pdf/{id}"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21775, 0, 0.0, 9.254328358209033, 0, 271, 4.0, 23.0, 37.0, 63.0, 60.73698861687024, 676.0523894879684, 11.995378196711139], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /jobs", 1281, 0, 0.0, 9.72677595628416, 3, 54, 9.0, 15.0, 17.0, 23.0, 3.631889177764106, 56.19851955241431, 0.6242309524282057], "isController": false}, {"data": ["GET /applications/seeker/{seekerId}", 1093, 0, 0.0, 11.283623055809693, 2, 52, 10.0, 20.0, 23.0, 31.0, 3.129930786434485, 5.391741697844271, 0.5990883145909756], "isController": false}, {"data": ["GET /jobseeker/jobs/search?title=java", 4394, 0, 0.0, 3.9736003641329245, 1, 53, 4.0, 7.0, 8.0, 10.0, 12.386257286862786, 360.6771677535885, 2.467574693867196], "isController": false}, {"data": ["GET /applications/employer/{userId}", 2044, 0, 0.0, 37.01712328767122, 10, 85, 35.0, 55.0, 60.0, 68.0, 5.802268675697464, 65.78387977395565, 1.1219230447149393], "isController": false}, {"data": ["GET /api/jobseeker/favorites/{seekerId}", 427, 0, 0.0, 9.658079625292746, 1, 36, 8.0, 17.0, 21.0, 25.0, 1.2373834700637236, 2.0054759697304703, 0.24167645899682103], "isController": false}, {"data": ["POST /applications/update-status/{id}", 193, 0, 0.0, 7.678756476683939, 2, 24, 7.0, 12.0, 15.299999999999983, 23.060000000000002, 0.5686488843580307, 0.11161955640230876, 0.17103892224831393], "isController": false}, {"data": ["GET /jobs/get/{id}", 4365, 0, 0.0, 2.4176403207330925, 0, 47, 2.0, 4.0, 5.0, 7.0, 12.357387537864847, 4.151915337563344, 2.232535834477536], "isController": false}, {"data": ["GET /jobseeker/dashboard/{userId}", 4417, 0, 0.0, 3.756622141725157, 1, 207, 3.0, 6.0, 8.0, 13.0, 12.376258430397906, 129.74524829132963, 2.3688932151933493], "isController": false}, {"data": ["POST /auth/register", 132, 0, 0.0, 95.93939393939391, 72, 119, 98.0, 107.0, 107.0, 116.02999999999989, 0.3899867936290339, 0.07236083084913715, 0.16833414334378222], "isController": false}, {"data": ["POST /applications/submit-application", 427, 0, 0.0, 11.051522248243558, 4, 45, 10.0, 18.0, 21.0, 28.87999999999988, 1.222364402000441, 0.2339681863203969, 0.4249626241329658], "isController": false}, {"data": ["GET /employer/dashboard/{userId}", 2054, 0, 0.0, 7.220058422590051, 2, 76, 6.0, 12.0, 14.0, 21.0, 5.800375584202872, 56.429036228520395, 1.1045637098823828], "isController": false}, {"data": ["POST /auth/login (seeker)", 80, 0, 0.0, 93.9125, 73, 131, 92.5, 112.9, 114.95, 131.0, 1.349800904366606, 0.4257672774515759, 0.35938119537524466], "isController": false}, {"data": ["POST /api/jobseeker/favorites/{userId}/{jobId}", 427, 0, 0.0, 8.016393442622945, 2, 70, 7.0, 13.0, 15.0, 21.87999999999988, 1.2402983687317004, 0.307652134431496, 0.3500451450815053], "isController": false}, {"data": ["POST /auth/login (employer)", 20, 0, 0.0, 90.10000000000001, 73, 115, 89.5, 109.20000000000002, 114.75, 115.0, 0.3554860382858463, 0.11178369563285401, 0.09338451591688736], "isController": false}, {"data": ["GET /api/resume/resume-pdf/{id}", 421, 0, 0.0, 14.000000000000005, 4, 271, 13.0, 22.0, 24.0, 34.77999999999997, 1.2239297156180409, 2.377198090371656, 0.23665828485583212], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21775, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
